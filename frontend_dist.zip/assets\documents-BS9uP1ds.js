import{V as nt,a7 as r,a5 as t,X as Pe,U as Ue,F as L,ad as i,i as q,N as $,ag as st,w as at,y as Ce,n as _e}from"./index-BP1Uz0fe.js";import{C as it,r as H,d as ot,f as C,g as W,a as J,o as rt}from"./company-acceptance-modal-BgLe7y-L.js";import{a as Fe}from"./print-fallback-DuorPCeU.js";import{e as lt}from"./logbook-export-BAj8vwwm.js";import{S as Le}from"./send-D5C1KrnX.js";import{C as dt}from"./clock-BKqePY6g.js";import"./date-utils-cNwPtUwz.js";import"./date-picker-5oVHhnwW.js";import"./utils-gPd2mQ4j.js";import"./clsx-B-dksMZM.js";/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ct=[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}]],mt=nt("file",ct),pt="iams_template_overrides",ut="insurance-letter";function gt(){try{const s=localStorage.getItem(pt);if(!s)return null;const e=JSON.parse(s);return(e==null?void 0:e[ut])??null}catch{return null}}function ft(s){const _=new Date().toLocaleDateString("en-GB",{year:"numeric",month:"long",day:"numeric"}),p=gt(),I=(p==null?void 0:p.signatureUrl)||s.signatureUrl,u=(p==null?void 0:p.coordinatorName)||s.coordinatorName||"Mrs. Stella A. B. Adzika",v=`
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Indemnity Form</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    body {
      font-family: 'Times New Roman', Times, Georgia, serif;
      line-height: 1.5;
      color: #000;
      background: white;
      padding: 0.3in 0.5in;
    }
    @media print {
      body {
        margin: 0;
        padding: 0.3in 0.4in;
        background: white;
      }
      .no-print {
        display: none !important;
      }
    }
    .container {
      max-width: 8.5in;
      margin: 0 auto;
    }
    .print-button {
      background: #1e3a8a;
      color: white;
      border: none;
      padding: 8px 16px;
      border-radius: 4px;
      font-size: 14px;
      cursor: pointer;
      margin-bottom: 0.2in;
      display: inline-block;
    }
    .letterhead {
      text-align: center;
      border-bottom: 2px solid #000;
      padding-bottom: 5px;
      margin-bottom: 15px;
    }
    .title {
      text-align: center;
      font-size: 16pt;
      font-weight: bold;
      letter-spacing: 2px;
      margin-bottom: 20px;
      text-decoration: underline;
    }
    .paragraph {
      font-size: 11pt;
      text-align: justify;
      margin-bottom: 15px;
      text-indent: 0.25in;
    }
    .underline-field {
      border-bottom: 1px dotted #000;
      display: inline-block;
      padding: 0 4px;
      font-weight: bold;
    }
    .sign-section {
      margin-top: 15px;
      font-size: 10pt;
    }
    .sign-block {
      margin-bottom: 15px;
      page-break-inside: avoid;
    }
    .sign-title {
      font-weight: bold;
      text-decoration: underline;
      margin-bottom: 6px;
    }
    .sign-row {
      margin-bottom: 4px;
      display: flex;
      align-items: flex-end;
    }
    .field-label {
      width: 100px;
      flex-shrink: 0;
    }
    .field-line {
      flex-grow: 1;
      border-bottom: 1px dotted #000;
      padding-bottom: 2px;
      position: relative;
    }
    .signature-img {
      position: absolute;
      bottom: 2px;
      left: 10px;
      max-height: 45px;
    }
    .right-sign-line {
      width: 2.2in;
      text-align: center;
      margin-left: 20px;
      border-top: 1px solid #000;
      margin-top: 25px;
      font-weight: bold;
      font-size: 9.5pt;
      position: relative;
    }
    .right-stamp-container {
      position: relative;
      width: 2.2in;
      height: 1.1in;
      display: flex;
      justify-content: center;
      align-items: center;
    }
    .insurance-stamp-img {
      max-height: 1.1in;
      opacity: 0.85;
    }
    .footer-note {
      border-top: 1px solid #ccc;
      margin-top: 20px;
      padding-top: 8px;
      font-size: 8.5pt;
      font-style: italic;
      color: #444;
      text-align: center;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="no-print" style="text-align: center;">
      <button class="print-button" onclick="window.print()">Print / Save as PDF</button>
    </div>
    
    <div class="letterhead">
      <img src="${window.location.origin}/HTULH.png" alt="HTU Letterhead" style="max-width: 100%; height: auto; max-height: 90px; object-fit: contain;" />
    </div>
    
    <div class="title">INDEMNITY FORM</div>
    
    <div class="paragraph" style="text-indent: 0;">
      I, <span class="underline-field" style="min-width: 250px; text-align: center; display: inline-block;">${s.studentName}</span> of <span class="underline-field" style="min-width: 250px; text-align: center; display: inline-block;">Ho Technical University</span><br/>
      <span style="font-size: 8.5pt; color: #555; display: inline-block; width: 250px; text-align: center; margin-top: 2px; font-style: italic;">(Name of Student)</span>
      <span style="font-size: 8.5pt; color: #555; display: inline-block; width: 250px; text-align: center; margin-top: 2px; font-style: italic;">(Institution)</span>
    </div>
    
    <div class="paragraph">
      declare that I accept to undertake industrial attachment training with <span class="underline-field">${s.companyName}</span> (hereinafter, referred to as <span class="underline-field">${s.companyName}</span>) - <span class="underline-field">${s.companyAddress||"—"}</span>, from <span class="underline-field">${s.startDate||"—"}</span> to <span class="underline-field">${s.endDate||"—"}</span>. During this period, <span class="underline-field">${s.companyName}</span> will not be responsible for the payment of salary or any other allowance or fringe benefit(s) otherwise specified.
    </div>
    
    <div class="paragraph">
      I, further, declare that <span class="underline-field">${s.companyName}</span> shall not be held liable whatsoever or under the Workmen's Compensation Law (1987) PNDC 187 for any loss, damage or injury that I may suffer if the loss, damage or injury was caused by any act of omission, arising from my negligence or an "Act of God".
    </div>
    
    <div class="sign-section">
      <!-- Student block -->
      <div class="sign-block" style="display: flex; justify-content: space-between;">
        <div style="width: 60%;">
          <p class="sign-title">SIGNED by the said Student:</p>
          <p style="margin-bottom: 8px; font-style: italic; color: #555;">in the presence of (Student's Witness):</p>
          <div class="sign-row">
            <span class="field-label">Name:</span>
            <span class="field-line"></span>
          </div>
          <div class="sign-row" style="margin-top: 8px;">
            <span class="field-label">Date:</span>
            <span class="field-line" style="width: 150px; flex-grow: 0;"></span>
            <span style="margin-left: 10px; margin-right: 5px;">Signature:</span>
            <span class="field-line"></span>
          </div>
        </div>
        <div style="display: flex; flex-direction: column; justify-content: flex-end; align-items: center;">
          <div class="right-sign-line">Signature of Student</div>
        </div>
      </div>
      
      <!-- HTU block -->
      <div class="sign-block" style="display: flex; justify-content: space-between;">
        <div style="width: 60%; space-y-2;">
          <p class="sign-title">SIGNED on behalf of the HTU:</p>
          <div class="sign-row" style="margin-top: 6px;">
            <span class="field-label">Name:</span>
            <span class="field-line">${u}</span>
          </div>
          <div class="sign-row" style="margin-top: 6px;">
            <span class="field-label">Designation:</span>
            <span class="field-line">Industrial Liaison Officer</span>
          </div>
          <div class="sign-row" style="margin-top: 6px;">
            <span class="field-label">Signature:</span>
            <span class="field-line" style="min-height: 25px;">
              <img class="signature-img" src="${I||`${window.location.origin}/Signature.png`}" alt="Signature" />
            </span>
          </div>
          <div class="sign-row" style="margin-top: 6px;">
            <span class="field-label">Date:</span>
            <span class="field-line">${_}</span>
          </div>
        </div>
        <div style="display: flex; flex-direction: column; justify-content: flex-end; align-items: center;">
          <div class="right-stamp-container">
            <img class="insurance-stamp-img" src="${window.location.origin}/Stamp.png" alt="University Stamp" />
          </div>
          <div class="right-sign-line">Industrial Liaison Office Stamp</div>
        </div>
      </div>
      
      <!-- Company block -->
      <div class="sign-block" style="display: flex; justify-content: space-between;">
        <div style="width: 60%;">
          <p class="sign-title">SIGNED on behalf of ${s.companyName}:</p>
          <p style="margin-bottom: 8px; font-style: italic; color: #555;">in the presence of (Witness):</p>
          <div class="sign-row">
            <span class="field-label">Name:</span>
            <span class="field-line"></span>
          </div>
          <div class="sign-row" style="margin-top: 8px;">
            <span class="field-label">Date:</span>
            <span class="field-line" style="width: 150px; flex-grow: 0;"></span>
            <span style="margin-left: 10px; margin-right: 5px;">Signature:</span>
            <span class="field-line"></span>
          </div>
        </div>
        <div style="display: flex; flex-direction: column; justify-content: flex-end; align-items: center;">
          <div class="right-sign-line">Signature Rep:</div>
        </div>
      </div>
    </div>
    
    <div class="footer-note">
      NB: Please scan this completed form and email to <strong style="color: #1e3a8a;">industrialliaison@htu.edu.gh</strong> or WhatsApp to <strong style="color: #1e3a8a;">0244 055762</strong> at the start of attachment.
    </div>
  </div>
</body>
</html>
  `;try{const d=window.open("","_blank");d?(d.document.open(),d.document.write(v),d.document.close()):Fe(v,"Indemnity Form")}catch(d){console.warn("Failed to open Indemnity Form window, displaying in-app modal instead",d),Fe(v,"Indemnity Form")}}function xt({isOpen:s,onClose:e,onSuccess:_,title:p,description:I,allowedTypes:u=[".pdf",".doc",".docx"],maxSizeMB:v=10}){const[d,w]=r.useState(null),[D,j]=r.useState(!1),[b,T]=r.useState(0);if(!s)return null;const R=N=>{if(N.target.files&&N.target.files[0]){const g=N.target.files[0];if(g.size/(1024*1024)>v){i.error(`File size exceeds the ${v}MB limit.`);return}const E=g.name.substring(g.name.lastIndexOf(".")).toLowerCase();if(u.length>0&&!u.includes(E)&&!u.some(y=>g.type.includes(y.replace(".","")))){i.error(`Invalid file type. Allowed formats: ${u.join(", ")}`);return}w(g)}},S=async()=>{var N;if(!d){i.error("Please select a file to upload.");return}j(!0),T(0);try{const g=await apiClient.uploadFile(d,"iams/student-documents");g.success&&((N=g.data)!=null&&N.url)?(i.success(`${d.name} uploaded successfully!`),_(g.data.url),w(null),e()):i.error(g.message??"Upload failed. Please try again.")}catch(g){console.error("Upload error:",g),i.error("An unexpected error occurred during upload.")}finally{j(!1)}};return t.jsx("div",{className:"fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4",onClick:e,children:t.jsxs("div",{className:"bg-card border border-border rounded-2xl w-full max-w-md overflow-hidden shadow-2xl animate-in fade-in zoom-in-95 duration-200",onClick:N=>N.stopPropagation(),children:[t.jsxs("div",{className:"p-6 border-b border-border flex items-center justify-between",children:[t.jsxs("div",{children:[t.jsx("h2",{className:"text-lg font-bold text-foreground",children:p}),t.jsx("p",{className:"text-muted-foreground text-xs mt-1",children:I})]}),t.jsx("button",{onClick:e,className:"p-1 rounded-md hover:bg-accent text-muted-foreground transition-colors",children:t.jsx(Pe,{className:"w-5 h-5"})})]}),t.jsx("div",{className:"p-6 space-y-6",children:D?t.jsxs("div",{className:"space-y-4 py-4",children:[t.jsxs("div",{className:"flex items-center gap-3",children:[t.jsx(L,{className:"w-8 h-8 text-primary animate-pulse"}),t.jsxs("div",{className:"flex-1 min-w-0",children:[t.jsx("p",{className:"text-sm font-medium truncate text-foreground",children:d==null?void 0:d.name}),t.jsx("p",{className:"text-xs text-muted-foreground mt-0.5",children:"Uploading..."})]}),t.jsxs("span",{className:"text-sm font-semibold text-primary",children:[b,"%"]})]}),t.jsx("div",{className:"w-full bg-secondary rounded-full h-2 overflow-hidden",children:t.jsx("div",{className:"bg-primary h-full transition-all duration-100 ease-out",style:{width:`${b}%`}})})]}):t.jsx("div",{className:"border-2 border-dashed border-border rounded-xl p-6 text-center hover:bg-muted/30 transition-colors",children:t.jsxs("label",{className:"cursor-pointer flex flex-col items-center gap-2",children:[t.jsx(Ue,{className:"w-8 h-8 text-muted-foreground"}),t.jsx("span",{className:"text-sm font-medium text-foreground",children:d?d.name:"Click to select file or drag & drop"}),d?t.jsxs("span",{className:"text-xs text-muted-foreground",children:[(d.size/1024/1024).toFixed(2)," MB"]}):t.jsxs("span",{className:"text-xs text-muted-foreground",children:["Supported formats: ",u.join(", ")," (Max ",v,"MB)"]}),t.jsx("input",{type:"file",onChange:R,accept:u.join(","),className:"hidden"})]})})}),t.jsxs("div",{className:"p-6 border-t border-border flex gap-3 justify-end bg-muted/20",children:[t.jsx("button",{onClick:e,disabled:D,className:"px-4 py-2 border border-border rounded-lg hover:bg-accent font-medium text-sm text-foreground transition-colors disabled:opacity-50",children:"Cancel"}),t.jsx("button",{onClick:S,disabled:!d||D,className:"px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:opacity-90 disabled:opacity-50 font-medium text-sm transition-opacity flex items-center gap-1.5",children:D?"Uploading...":"Upload Document"})]})]})})}function ht({isOpen:s,onClose:e,applicationId:_,initialName:p="",initialEmail:I="",initialPhone:u="",studentName:v="Student",companyName:d="Company"}){const[w,D]=r.useState(p),[j,b]=r.useState(I),[T,R]=r.useState(u),[S,N]=r.useState(!1),[g,z]=r.useState(!1),E=async()=>{if(!w.trim()||!j.trim()){i.error("Please provide supervisor name and email.");return}N(!0);try{const y=await $.requestMagicLink(j,{role:"industry_supervisor",name:w,phone:T||void 0,application_id:_,company_name:d,student_name:v});y.success?(z(!0),i.success(`Magic link sent to ${j}`),setTimeout(()=>{e(),z(!1),D(""),b(""),R("")},2e3)):i.error(y.message??"Failed to send magic link.")}catch(y){console.error("Error sending magic link:",y),i.error("An error occurred while sending the link.")}finally{N(!1)}};return s?t.jsx("div",{className:"fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4",children:t.jsxs("div",{className:"bg-background rounded-2xl shadow-xl max-w-md w-full p-6 space-y-4",children:[t.jsxs("div",{className:"flex items-center justify-between",children:[t.jsx("h2",{className:"text-xl font-bold",children:"Invite Supervisor"}),t.jsx("button",{onClick:e,disabled:S,className:"p-1 hover:bg-accent rounded-lg transition-colors disabled:opacity-50",children:t.jsx(Pe,{className:"w-5 h-5"})})]}),g?t.jsxs("div",{className:"bg-emerald-50 border border-emerald-200 rounded-lg p-4 text-center space-y-2",children:[t.jsx(q,{className:"w-8 h-8 text-emerald-600 mx-auto"}),t.jsx("p",{className:"font-semibold text-emerald-900 text-sm",children:"Link Sent Successfully!"}),t.jsxs("p",{className:"text-xs text-emerald-700",children:[w," will receive an email with access link. It expires in 30 days."]})]}):t.jsxs("div",{className:"space-y-4",children:[t.jsx("p",{className:"text-sm text-muted-foreground",children:"Send a secure access link to your supervisor so they can evaluate your internship performance."}),t.jsxs("div",{className:"space-y-3",children:[t.jsxs("div",{children:[t.jsx("label",{className:"text-xs font-semibold text-muted-foreground block mb-1",children:"Supervisor Name *"}),t.jsx("input",{type:"text",value:w,onChange:y=>D(y.target.value),placeholder:"e.g., John Doe",disabled:S,className:"w-full px-3 py-2.5 border border-border rounded-lg bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary disabled:opacity-50"})]}),t.jsxs("div",{children:[t.jsx("label",{className:"text-xs font-semibold text-muted-foreground block mb-1",children:"Email Address *"}),t.jsx("input",{type:"email",value:j,onChange:y=>b(y.target.value),placeholder:"supervisor@company.com",disabled:S,className:"w-full px-3 py-2.5 border border-border rounded-lg bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary disabled:opacity-50"})]}),t.jsxs("div",{children:[t.jsx("label",{className:"text-xs font-semibold text-muted-foreground block mb-1",children:"Phone Number (Optional)"}),t.jsx("input",{type:"tel",value:T,onChange:y=>R(y.target.value),placeholder:"+233 XX XXX XXXX",disabled:S,className:"w-full px-3 py-2.5 border border-border rounded-lg bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary disabled:opacity-50"})]})]}),t.jsx("div",{className:"bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800 rounded-lg p-3",children:t.jsxs("p",{className:"text-xs text-blue-700 dark:text-blue-300",children:[t.jsx("span",{className:"font-semibold",children:"Note:"})," The supervisor will receive a secure magic link via email and can access the system for 30 days."]})}),t.jsxs("div",{className:"flex gap-2 pt-2",children:[t.jsx("button",{onClick:e,disabled:S,className:"flex-1 px-4 py-2.5 border border-border rounded-lg hover:bg-accent font-medium text-sm transition-colors disabled:opacity-50",children:"Cancel"}),t.jsxs("button",{onClick:E,disabled:S||!w.trim()||!j.trim(),className:"flex-1 px-4 py-2.5 bg-primary text-primary-foreground rounded-lg hover:opacity-90 font-medium text-sm flex items-center justify-center gap-2 transition-all disabled:opacity-50 disabled:cursor-not-allowed",children:[t.jsx(Le,{className:"w-4 h-4"}),S?"Sending...":"Send Link"]})]})]})]})}):null}function Pt(){var oe,re,le,de,ce,me,pe,ue,ge,fe,xe,he,be,ye;const{user:s}=st(),[e,_]=r.useState(null),[p,I]=r.useState(null),[u,v]=r.useState(null),[d,w]=r.useState(!1),[D,j]=r.useState("Company"),[b,T]=r.useState([]),[R,S]=r.useState([]),[N,g]=r.useState(!1),[z,E]=r.useState(!1),[y,ee]=r.useState(!1),[te,ne]=r.useState(!1),[V,A]=r.useState(null),[se,M]=r.useState(null),K=async()=>{var n;try{const[a,c,f]=await Promise.all([$.getTerms(),$.getTemplates(),$.getApplications()]);if(a.success&&T(a.data),c.success){const o=c.data.filter(l=>{var U;const m=["placement-letter","acceptance-form","insurance-letter","logbook-template"].includes(l.slug??l.id);let h=!1;try{const G=l.visible_to?JSON.parse(l.visible_to):l.visibleTo;h=Array.isArray(G)?G.includes("Student"):!1}catch{h=((U=l.visibleTo)==null?void 0:U.includes("Student"))||!1}const k=l.status==="Active";return!m&&h&&k});S(o)}let x=null;if(f.success&&f.data.length>0&&(x=[...f.data].sort((l,m)=>(m.created_at??"")>(l.created_at??"")?1:-1)[0],_(x)),x){const o=x.internship;if(o){I(String(o.id)),v(o.status||null),j(((n=o.company)==null?void 0:n.name)||o.companyName||"Company");const l=!!(o.status==="completed"||o.end_date&&new Date(o.end_date).toISOString().split("T")[0]<new Date().toISOString().split("T")[0]);if(w(l),o.final_report_url)M(o.final_report_url),A(o.final_report_name||"Final Internship Report");else{const m=localStorage.getItem(`iams_final_report_url_${o.id}`),h=localStorage.getItem(`iams_final_report_name_${o.id}`);M(m),A(h)}}else I(null),v(null),j("Company"),w(!1),M(null),A(null)}else I(null),v(null),j("Company"),w(!1),M(null),A(null)}catch(a){console.error("Error fetching documents details:",a)}};r.useEffect(()=>{K()},[]);const[B,$e]=r.useState(""),[X,Te]=r.useState(""),[ae,Re]=r.useState(""),[Ee,Oe]=r.useState(""),[ze,Ae]=r.useState(!1),Me=!!p&&(u==null?void 0:u.toLowerCase())==="active"&&!d,Be=!!p&&((u==null?void 0:u.toLowerCase())==="completed"||d),F=!!(e!=null&&e.status&&["approved","active","completed","company accepted","company_accepted"].includes(e.status.toLowerCase())),O=((oe=e==null?void 0:e.status)==null?void 0:oe.toLowerCase())==="active"||Me,P=((re=e==null?void 0:e.status)==null?void 0:re.toLowerCase())==="completed"||Be,Z=((le=e==null?void 0:e.status)==null?void 0:le.toLowerCase())==="approved",He=()=>{var f,x,o,l,m,h,k,U;if(!e)return;const n=typeof((f=e.company)==null?void 0:f.name)=="string"?e.company.name:typeof e.companyName=="string"?e.companyName:"Company",a=typeof((x=e.company)==null?void 0:x.address)=="string"?e.company.address:void 0,c=typeof((l=(o=e.academic_supervisor)==null?void 0:o.user)==null?void 0:l.name)=="string"?e.academic_supervisor.user.name:typeof e.supervisorAssigned=="string"?e.supervisorAssigned:void 0;rt({studentName:((h=(m=e.student)==null?void 0:m.user)==null?void 0:h.name)??e.studentName??(s==null?void 0:s.name)??"Student",studentId:((k=e.student)==null?void 0:k.student_id)??e.studentId??(s==null?void 0:s.studentId)??"—",department:H(e,(s==null?void 0:s.department)??"—"),level:((U=e.student)==null?void 0:U.level)??e.level??"—",companyName:n,companyAddress:a,supervisorName:c,startDate:C(J(e,b)),endDate:C(W(e,b))})},qe=async()=>{var a,c,f,x,o,l;if(!e){i.error("No active application data found to generate form.");return}ne(!0);const n=i.loading("Preparing your acceptance form download...");try{const m=typeof((a=e.company)==null?void 0:a.name)=="string"?e.company.name:typeof e.companyName=="string"?e.companyName:"Company",h=typeof((c=e.company)==null?void 0:c.address)=="string"?e.company.address:void 0;await ot({studentName:((x=(f=e.student)==null?void 0:f.user)==null?void 0:x.name)??e.studentName??(s==null?void 0:s.name)??"Student",studentId:((o=e.student)==null?void 0:o.student_id)??e.studentId??(s==null?void 0:s.studentId)??"",department:H(e,(s==null?void 0:s.department)??""),level:((l=e.student)==null?void 0:l.level)??e.level??"",companyName:m,companyAddress:h,startDate:C(J(e,b)),endDate:C(W(e,b))}),i.success("Acceptance Form downloaded successfully!",{id:n})}catch(m){console.error("Download pipeline error:",m),i.error("Could not complete document export. Please check application data.",{id:n})}finally{ne(!1)}},Xe=async()=>{if(!p){i.error("No active/completed internship found for logbook export.");return}const n=i.loading("Generating logbook export PDF...");try{const a=await $.getInternshipLogbooks(p,{per_page:100});i.dismiss(n),a.success?(lt(D,a.data??[]),i.success("Logbook PDF generated successfully!")):i.error("Failed to load logbook entries.")}catch{i.dismiss(n),i.error("An error occurred while generating PDF.")}},Ge=()=>{var c,f,x,o,l,m;if(!e)return;const n=typeof((c=e.company)==null?void 0:c.name)=="string"?e.company.name:typeof e.companyName=="string"?e.companyName:"Company",a=typeof((f=e.company)==null?void 0:f.address)=="string"?e.company.address:typeof e.companyAddress=="string"?e.companyAddress:"—";ft({studentName:((o=(x=e.student)==null?void 0:x.user)==null?void 0:o.name)??(s==null?void 0:s.name)??"Student",studentId:((l=e.student)==null?void 0:l.student_id)??(s==null?void 0:s.studentId)??"—",department:H(e,(s==null?void 0:s.department)??"—"),level:((m=e.student)==null?void 0:m.level)??e.level??"—",companyName:n,companyAddress:a,startDate:C(J(e,b)),endDate:C(W(e,b))})},Ye=n=>{var ve,Ne,we,je,Se,ke,Ie,De;const a=n.rawTemplate,c=a.body||"",f=((Ne=(ve=e==null?void 0:e.student)==null?void 0:ve.user)==null?void 0:Ne.name)??(s==null?void 0:s.name)??"Student",x=((we=e==null?void 0:e.student)==null?void 0:we.student_id)??(s==null?void 0:s.studentId)??"—",o=H(e,(s==null?void 0:s.department)??"—"),l=((je=e==null?void 0:e.student)==null?void 0:je.level)??(e==null?void 0:e.level)??"—",m=typeof((Se=e==null?void 0:e.company)==null?void 0:Se.name)=="string"?e.company.name:typeof(e==null?void 0:e.companyName)=="string"?e.companyName:"Company",h=typeof((ke=e==null?void 0:e.company)==null?void 0:ke.address)=="string"?e.company.address:"—",k=typeof((De=(Ie=e==null?void 0:e.academic_supervisor)==null?void 0:Ie.user)==null?void 0:De.name)=="string"?e.academic_supervisor.user.name:typeof(e==null?void 0:e.supervisorAssigned)=="string"?e.supervisorAssigned:"—",U=C(J(e,b))??"—",G=C(W(e,b))??"—",Ke=c.split("[Student Name]").join(f).split("[Student ID]").join(x).split("[Department]").join(o).split("[Level]").join(l).split("[Company Name]").join(m).split("[Company Address]").join(h).split("[Start Date]").join(U).split("[End Date]").join(G).split("[Supervisor Name]").join(k).split(`
`).filter(Q=>Q.trim().length>0).map(Q=>`<p style="margin-bottom: 0.15in; text-align: justify;">${Q}</p>`).join(`
`),Ze=new Date().toLocaleDateString("en-GB",{year:"numeric",month:"long",day:"numeric"}),Qe=a.has_letterhead||a.hasLetterhead?`
      <div class="letterhead" style="text-align: center; margin-bottom: 0.3in; border-bottom: 2px solid #1e3a8a; padding-bottom: 10px;">
        <img src="${window.location.origin}/HTULH.png" alt="HTU Letterhead" style="max-width: 100%; height: auto; max-height: 100px; object-fit: contain;" />
      </div>
      `:"",et=a.has_signature||a.hasSignature?`
      <div class="signature-section" style="margin-top: 0.4in; page-break-inside: avoid;">
        <p style="margin-bottom: 0.05in;">Yours faithfully,</p>
        <img src="${a.signature_url||`${window.location.origin}/Signature.png`}" alt="Signature" style="max-height: 60px; object-fit: contain; display: block; margin-bottom: 0.05in;" />
        <p style="font-weight: bold; border-top: 1px solid #ccc; display: inline-block; padding-top: 2px;">Industrial Liaison Officer</p>
        <p style="font-size: 10pt; color: #555; margin-top: 2px;">Industrial Liaison Office</p>
        <p style="font-size: 10pt; color: #555;">Ho Technical University</p>
      </div>
      `:"",tt=`
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>${a.name}</title>
  <style>
    body {
      font-family: 'Times New Roman', Times, Georgia, serif;
      line-height: 1.6;
      color: #333;
      padding: 0.5in;
      background: white;
    }
    @media print {
      body {
        margin: 1in;
        padding: 0;
      }
      .no-print {
        display: none !important;
      }
    }
    .container {
      max-width: 8.5in;
      margin: 0 auto;
    }
    .print-button {
      background: #1e3a8a;
      color: white;
      border: none;
      padding: 8px 16px;
      border-radius: 4px;
      font-size: 14px;
      cursor: pointer;
      margin-bottom: 0.3in;
      display: inline-block;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="no-print" style="text-align: center;">
      <button class="print-button" onclick="window.print()">Print / Save as PDF</button>
    </div>
    ${Qe}
    <div class="date" style="text-align: right; margin-bottom: 0.2in;">Date: ${Ze}</div>
    <div class="body" style="font-size: 11pt;">
      ${Ke}
    </div>
    ${et}
  </div>
</body>
</html>
    `,Y=window.open("","_blank");Y?(Y.document.open(),Y.document.write(tt),Y.document.close()):i.error("Popup blocker prevented opening print window.")},We=async n=>{if(!p){i.error("No active internship found to attach the report to.");return}const a=i.loading("Submitting final report...");try{const c=await $.submitFinalReport(p,{report_url:n,report_name:"Final Internship Report"});c.success?(A("Final Internship Report"),M(n),localStorage.setItem(`iams_final_report_name_${p}`,"Final Internship Report"),localStorage.setItem(`iams_final_report_url_${p}`,n),i.success("Final report submitted successfully!",{id:a}),K()):i.error(c.message??"Failed to submit final report record.",{id:a})}catch(c){console.error("Report submission error:",c),i.error("An error occurred during report submission.",{id:a})}},Je=[...[{id:"placement-letter",name:"Placement Letter",desc:"Official letter from the university to the company requesting student placement",status:F?"Available":"Pending",canDownload:!!F,canUpload:!1,icon:L},{id:"insurance-letter",name:"Insurance Letter",desc:"Official letter confirming student Group Personal Accident Insurance cover during industrial attachment",status:F?"Available":"Pending",canDownload:!!F,canUpload:!1,icon:at},{id:"acceptance-form",name:"Company Acceptance Form",desc:"Form to be signed by the company confirming acceptance of the student. After download, share with your supervisor and invite them to the system.",status:((de=e==null?void 0:e.status)==null?void 0:de.toLowerCase())==="company accepted"||((ce=e==null?void 0:e.status)==null?void 0:ce.toLowerCase())==="company_accepted"||O||P?"Uploaded":Z?"Action Required":F?"Available":"Pending",canDownload:!!e,canUpload:Z,icon:mt},{id:"logbook-form",name:"Logbook Form (Manual)",desc:"Printable blank weekly logbook sheet to document activities manually if your industrial supervisor cannot use the digital portal.",status:"Available",canDownload:!0,canUpload:!1,icon:L},{id:"final-report",name:"Final Internship Report",desc:"Your comprehensive final report documenting the internship experience, tasks, and learnings",status:V?"Submitted":O||P?"Not Submitted":"Not Available Yet",canDownload:!!V,canUpload:O||P,icon:L},{id:"logbook-export",name:"Logbook Export (PDF)",desc:"Auto-generated PDF of all your approved logbook entries",status:O||P?"Available":"Pending",canDownload:!!O||!!P,canUpload:!1,icon:L}],...R.map(n=>({id:`custom-${n.slug??n.id}`,name:n.name,desc:n.desc||"Additional document template",status:F?"Available":"Pending",canDownload:!!F,canUpload:!1,icon:L,rawTemplate:n}))],ie=async(n,a,c,f)=>{var l,m,h;if(!n.trim()||!a.trim())return!1;const x=typeof((l=e==null?void 0:e.company)==null?void 0:l.name)=="string"?e.company.name:typeof(e==null?void 0:e.companyName)=="string"?e.companyName:void 0,o=((h=(m=e==null?void 0:e.student)==null?void 0:m.user)==null?void 0:h.name)??(e==null?void 0:e.studentName)??(s==null?void 0:s.name);try{const k=await $.requestMagicLink(a,{role:"industry_supervisor",name:n,phone:c||void 0,job_title:f||void 0,application_id:e==null?void 0:e.id,company_name:x,student_name:o});return k.success?($e(n),Te(a),Re(c||""),Oe(f||""),Ae(!0),i.success(`Supervisor invite sent to ${a}!`),!0):(i.error(k.message??"Failed to send supervisor invite."),!1)}catch(k){return console.error("Error sending supervisor invite:",k),i.error("Failed to send supervisor invite."),!1}},Ve=n=>{const a={Available:"bg-emerald-100 text-emerald-700",Uploaded:"bg-emerald-100 text-emerald-700",Submitted:"bg-emerald-100 text-emerald-700","Action Required":"bg-red-100 text-red-700","Not Submitted":"bg-amber-100 text-amber-700","Not Available Yet":"bg-gray-100 text-gray-500",Pending:"bg-gray-100 text-gray-500"},c={Available:t.jsx(q,{className:"w-3 h-3"}),Uploaded:t.jsx(q,{className:"w-3 h-3"}),Submitted:t.jsx(q,{className:"w-3 h-3"}),"Action Required":t.jsx(Ce,{className:"w-3 h-3"}),"Not Submitted":t.jsx(dt,{className:"w-3 h-3"})};return t.jsxs("span",{className:`inline-flex items-center gap-1 px-2 py-0.5 rounded-full ${a[n]||a.Pending}`,style:{fontSize:"0.7rem"},children:[c[n]," ",n]})};return t.jsxs("div",{className:"space-y-4",children:[t.jsxs("div",{children:[t.jsx("h1",{className:"text-2xl font-bold",children:"Documents"}),t.jsx("p",{className:"text-muted-foreground text-sm mt-1",children:"Manage documents"})]}),Z&&t.jsxs("div",{className:"bg-amber-50 border border-amber-200 rounded-lg p-3 flex items-start gap-2 animate-in fade-in slide-in-from-top-1",children:[t.jsx(Ce,{className:"w-4 h-4 text-amber-600 mt-0.5 shrink-0"}),t.jsxs("div",{children:[t.jsx("p",{className:"text-amber-800 font-semibold text-sm",children:"Action Required"}),t.jsx("p",{className:"text-amber-700 text-xs mt-1",children:"Please upload your signed Company Acceptance Form to verify and start your internship."})]})]}),(O||P)&&t.jsxs("div",{className:"bg-blue-50 border border-blue-200 rounded-lg p-3 flex items-start gap-2 animate-in fade-in slide-in-from-top-1",children:[t.jsx(L,{className:"w-4 h-4 text-blue-600 mt-0.5 shrink-0"}),t.jsxs("div",{children:[t.jsx("p",{className:"text-blue-800 font-semibold text-sm",children:P?"Internship Completed":"Final Report Due"}),t.jsx("p",{className:"text-blue-700 text-xs mt-1",children:V?"Your final internship report has been uploaded.":"Please upload your comprehensive final report below before the term ends."})]})]}),t.jsx("div",{className:"space-y-2",children:Je.map(n=>t.jsxs("div",{className:`bg-card border rounded-lg p-3 space-y-2 transition-all ${n.status==="Action Required"?"border-red-200":"border-border"}`,children:[t.jsxs("div",{className:"flex items-start gap-2",children:[t.jsx("div",{className:`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${n.status==="Available"||n.status==="Uploaded"||n.status==="Submitted"?"bg-emerald-100":n.status==="Action Required"?"bg-red-100":"bg-secondary"}`,children:t.jsx(n.icon,{className:`w-4 h-4 ${n.status==="Available"||n.status==="Uploaded"||n.status==="Submitted"?"text-emerald-600":n.status==="Action Required"?"text-red-600":"text-muted-foreground"}`})}),t.jsxs("div",{className:"flex-1 min-w-0",children:[t.jsx("p",{className:"font-medium text-sm text-foreground",children:n.name}),Ve(n.status)]})]}),t.jsx("p",{className:"text-xs text-muted-foreground line-clamp-2 ml-11",children:n.desc}),t.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-2 ml-11",children:[n.id==="acceptance-form"&&n.canDownload?t.jsxs(t.Fragment,{children:[t.jsxs("button",{onClick:qe,disabled:te,className:"px-2.5 py-1.5 border border-primary text-primary hover:bg-primary/5 rounded text-xs font-medium flex items-center justify-center gap-1 transition-colors disabled:opacity-50",children:[t.jsx(_e,{className:"w-3 h-3"})," ",te?"Downloading...":"Download Form"]}),t.jsxs("button",{onClick:()=>ee(!0),className:"px-2.5 py-1.5 border border-blue-300 text-blue-600 hover:bg-blue-50 rounded text-xs font-medium flex items-center justify-center gap-1 transition-colors",children:[t.jsx(Le,{className:"w-3 h-3"})," Invite Supervisor"]})]}):n.canDownload?t.jsxs("button",{onClick:()=>{n.id==="placement-letter"?He():n.id==="insurance-letter"?Ge():n.id==="logbook-form"?window.open("/logbook.pdf","_blank"):n.id==="logbook-export"?Xe():n.id==="final-report"&&se?window.open(se,"_blank"):n.id.startsWith("custom-")&&Ye(n)},className:"px-2.5 py-1.5 border border-primary text-primary hover:bg-primary/5 rounded text-xs font-medium flex items-center justify-center gap-1 transition-colors",children:[t.jsx(_e,{className:"w-3 h-3"})," Download"]}):null,n.canUpload&&t.jsxs("button",{onClick:()=>{if(n.id==="acceptance-form"){if(!(e!=null&&e.id)){i.error("No application ID found to upload acceptance form.");return}g(!0)}else n.id==="final-report"&&E(!0)},className:"px-2.5 py-1.5 bg-primary text-primary-foreground hover:opacity-90 rounded text-xs font-medium flex items-center justify-center gap-1 transition-opacity",children:[t.jsx(Ue,{className:"w-3 h-3"})," ",n.id==="acceptance-form"?"Upload Signed Form":"Upload"]}),!n.canDownload&&!n.canUpload&&t.jsx("button",{disabled:!0,className:"px-2.5 py-1.5 bg-secondary text-muted-foreground rounded text-xs opacity-50 cursor-not-allowed flex items-center justify-center gap-1",children:"Not Available"})]})]},n.id))}),ze&&B&&t.jsx("div",{className:"bg-emerald-50 border border-emerald-200 rounded-lg p-4",children:t.jsxs("div",{className:"flex items-start gap-3",children:[t.jsx(q,{className:"w-5 h-5 text-emerald-600 mt-0.5 shrink-0"}),t.jsxs("div",{className:"flex-1 min-w-0",children:[t.jsx("h3",{className:"font-semibold text-emerald-900 text-sm",children:"Supervisor Invited"}),t.jsxs("p",{className:"text-emerald-700 text-xs mt-1",children:[t.jsx("span",{className:"font-medium",children:B})," (",X,")"]}),t.jsx("p",{className:"text-emerald-600 text-xs mt-2",children:"Access link sent. Link expires in 30 days."})]}),t.jsx("button",{onClick:()=>{X&&B&&ie(B,X,ae,Ee)},className:"ml-auto px-3 py-1.5 text-emerald-600 hover:bg-emerald-100 rounded text-xs font-medium whitespace-nowrap shrink-0 transition-colors",children:"Resend Invite"})]})}),e&&t.jsx(it,{isOpen:N,onClose:()=>g(!1),onSuccess:async n=>{K(),n!=null&&n.name&&(n!=null&&n.email)&&await ie(n.name,n.email,n.phone,n.title)},applicationId:e.id,companyName:typeof((me=e.company)==null?void 0:me.name)=="string"?e.company.name:typeof e.companyName=="string"?e.companyName:"Company",studentName:((ue=(pe=e.student)==null?void 0:pe.user)==null?void 0:ue.name)??e.studentName??(s==null?void 0:s.name)??"Student",studentId:((ge=e.student)==null?void 0:ge.student_id)??e.studentId??(s==null?void 0:s.studentId),department:H(e,(s==null?void 0:s.department)??""),level:((fe=e.student)==null?void 0:fe.level)??e.level,companyAddress:typeof((xe=e.company)==null?void 0:xe.address)=="string"?e.company.address:void 0,proposedStartDate:e.proposed_start_date,proposedEndDate:e.proposed_end_date}),t.jsx(xt,{isOpen:z,onClose:()=>E(!1),onSuccess:We,title:"Upload Final Report",description:"Select your comprehensive internship report to upload (PDF, DOCX, or DOC formats allowed. Max 10MB)."}),t.jsx(ht,{isOpen:y,onClose:()=>ee(!1),applicationId:e==null?void 0:e.id,initialName:B||"",initialEmail:X||"",initialPhone:ae||"",studentName:((be=(he=e==null?void 0:e.student)==null?void 0:he.user)==null?void 0:be.name)??(e==null?void 0:e.studentName)??(s==null?void 0:s.name)??"Student",companyName:typeof((ye=e==null?void 0:e.company)==null?void 0:ye.name)=="string"?e.company.name:typeof(e==null?void 0:e.companyName)=="string"?e.companyName:"Company"})]})}export{Pt as DocumentsPage};
