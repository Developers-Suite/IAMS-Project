import{a as O}from"./print-fallback-DuorPCeU.js";import{f as te}from"./date-utils-cNwPtUwz.js";import{a7 as l,a5 as t,n as ie,X as ne,o as re,i as se,U as oe,h as ae,ad as m,N as M}from"./index-BP1Uz0fe.js";import{D as H}from"./date-picker-5oVHhnwW.js";const le="iams_template_overrides",de="placement-letter";function ce(e){try{const i=new URL(e);return i.protocol==="https:"||i.protocol==="http:"}catch{return!1}}function me(){try{const e=localStorage.getItem(le);if(!e)return null;const i=JSON.parse(e);return(i==null?void 0:i[de])??null}catch{return null}}function pe(e,i){const r=i.supervisorName||i.dloName||"";return e.split("[Student Name]").join(i.studentName).split("[Student ID]").join(i.studentId).split("[Company Name]").join(i.companyName).split("[Start Date]").join(i.startDate||"").split("[End Date]").join(i.endDate||"").split("[Department]").join(i.department).split("[Supervisor Name]").join(r)}function ue(e,i){return pe(e,i).split(`
`).filter(n=>n.trim().length>0).map(n=>`<p>${n}</p>`).join(`
`)}function ve(e){const r=new Date().toLocaleDateString("en-GB",{year:"numeric",month:"long",day:"numeric"}),n=e.level||"Level 4",a=e.supervisorName?`For queries, please contact ${e.supervisorName}, Department of ${e.department}.`:`For queries, please contact the Department of ${e.department}.`,s=me(),d=`
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Placement Letter</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    body {
      font-family: 'Times New Roman', Times, Georgia, serif;
      line-height: 1.6;
      color: #333;
      background: white;
      padding: 0.5in;
    }
    @media print {
      body {
        margin: 1in;
        padding: 0;
        background: white;
      }
      .no-print {
        display: none !important;
      }
    }
    .container {
      max-width: 8.5in;
      margin: 0 auto;
      height: 11in;
      display: flex;
      flex-direction: column;
    }
    .letterhead {
      text-align: center;
      border-bottom: 3px solid #1e3a5f;
      padding-bottom: 0.3in;
      margin-bottom: 0.3in;
    }
    .letterhead-logo {
      height: 0.8in;
      margin-bottom: 0.1in;
    }
    .letterhead-title {
      font-size: 18px;
      font-weight: bold;
      color: #1e3a5f;
      margin-bottom: 0.05in;
    }
    .letterhead-subtitle {
      font-size: 12px;
      color: #555;
      font-style: italic;
    }
    .date {
      text-align: right;
      font-size: 11px;
      margin-bottom: 0.3in;
      margin-top: 0.2in;
    }
    .recipient {
      font-size: 11px;
      margin-bottom: 0.2in;
    }
    .recipient-line {
      margin: 0.05in 0;
    }
    .salutation {
      margin: 0.2in 0;
      font-size: 12px;
    }
    .body {
      font-size: 12px;
      flex-grow: 1;
      margin-bottom: 0.3in;
    }
    .body p {
      margin-bottom: 0.15in;
      text-align: justify;
    }
    .body p:first-child {
      text-indent: 0.5in;
    }
    .signature-block {
      margin-top: 0.4in;
      font-size: 11px;
      position: relative;
    }
    .signature-container {
      position: relative;
      height: 1.2in;
      margin-top: 0.1in;
      margin-bottom: 0.1in;
    }
    .signature-line {
      border-top: 1px solid #333;
      width: 2in;
      margin-top: 0.35in;
      margin-bottom: 0.05in;
      display: inline-block;
    }
    .signature-image {
      height: 0.8in;
      position: absolute;
      top: 0;
      left: 0;
      z-index: 2;
    }
    .stamp-image {
      height: 1.1in;
      position: absolute;
      top: -0.15in;
      left: 0.5in;
      z-index: 1;
      opacity: 0.85;
    }
    .signature-title {
      font-weight: bold;
      font-size: 11px;
    }
    .signature-subtitle {
      font-size: 10px;
      color: #666;
    }
    .closing {
      margin-bottom: 0.15in;
    }
    .print-button {
      display: block;
      margin: 0.3in 0;
      padding: 0.5in 1in;
      background: #1e3a5f;
      color: white;
      border: none;
      border-radius: 4px;
      font-size: 14px;
      cursor: pointer;
      text-align: center;
    }
    .print-button:hover {
      background: #152d4a;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="no-print" style="text-align: center; margin-bottom: 0.3in;">
      <button class="print-button" onclick="window.print()">Print / Save as PDF</button>
    </div>

    <div class="letterhead" style="text-align: center; border-bottom: 2px solid #1e3a8a; padding-bottom: 10px; margin-bottom: 20px;">
      <img src="${window.location.origin}/HTULH.png" alt="Ho Technical University Letterhead" style="max-width: 100%; height: auto; max-height: 100px; object-fit: contain;" />
    </div>

    <div class="date">Date: ${r}</div>

    <div class="recipient">
      <div class="recipient-line"><strong>TO: The Manager</strong></div>
      <div class="recipient-line">${e.companyName}</div>
      ${e.companyAddress?`<div class="recipient-line">${e.companyAddress}</div>`:""}
    </div>

    <div class="salutation">Dear Sir/Madam,</div>

    <div class="body">
      ${s!=null&&s.body?ue(s.body,e):`
      <p><strong>LETTER OF INTRODUCTION — INDUSTRIAL ATTACHMENT</strong></p>

      <p>
        We write to introduce <strong>${e.studentName}</strong> (Student ID: <strong>${e.studentId}</strong>),
        a ${n} student of the Department of <strong>${e.department}</strong>.
        This student is expected to undertake Industrial Attachment at your esteemed organisation
        ${e.startDate?`from <strong>${e.startDate}</strong>`:""}
        ${e.endDate?`to <strong>${e.endDate}</strong>`:""}
        as part of the academic programme.
      </p>

      <p>
        We kindly request that you extend to this student the necessary guidance and supervision
        during the attachment period. The student will contribute meaningfully to your operations
        whilst gaining invaluable practical experience in the profession.
      </p>

      <p>${a}</p>
      `}
    </div>

    <div class="closing">Yours faithfully,</div>

    <div class="signature-block">
      <div class="signature-container">
        <img class="signature-image" src="${s!=null&&s.signatureUrl&&ce(s.signatureUrl)?s.signatureUrl:`${window.location.origin}/Signature.png`}" alt="Signature" />
        <img class="stamp-image" src="${window.location.origin}/Stamp.png" alt="University Stamp" />
      </div>
      <div class="signature-title">${e.dloName||"Industrial Liaison Officer"}</div>
      <div class="signature-subtitle">Industrial Liaison Office</div>
      <div class="signature-subtitle">${e.universityName||"Ho Technical University"}</div>
    </div>
  </div>
</body>
</html>
`;try{const c=new Blob([d],{type:"text/html;charset=utf-8"}),h=URL.createObjectURL(c);if(!window.open(h,"_blank")){O(d,"Placement Letter"),URL.revokeObjectURL(h);return}setTimeout(()=>URL.revokeObjectURL(h),3e4)}catch(c){console.warn("Failed to open placement letter window, displaying in-app modal instead",c),O(d,"Placement Letter")}}function T(e){return(e!=null?String(e):"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function p(e,i=""){if(e==null)return i;typeof e=="object"&&(e=e.name||e.title||JSON.stringify(e));const r=String(e).trim();return r?T(r):i}async function ge(e){const r=new Date().toLocaleDateString("en-GB",{year:"numeric",month:"long",day:"numeric"}),n=`
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Company Acceptance Form - ${T(e.studentName)}</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    body {
      font-family: Arial, Helvetica, sans-serif;
      line-height: 1.5;
      color: #222;
      background: white;
      padding: 0.5in;
    }
    @media print {
      body {
        margin: 0.5in;
        padding: 0;
        background: white;
      }
      .no-print {
        display: none !important;
      }
    }
    .container {
      max-width: 8.5in;
      margin: 0 auto;
      min-height: 11in;
      display: flex;
      flex-direction: column;
    }
    .letterhead {
      text-align: center;
      border-bottom: 3px solid #1e3a5f;
      padding-bottom: 0.22in;
      margin-bottom: 0.28in;
    }
    .letterhead-logo {
      height: 0.8in;
      margin-bottom: 0.1in;
    }
    .letterhead-title {
      font-size: 18px;
      font-weight: bold;
      color: #1e3a5f;
    }
    .letterhead-subtitle {
      font-size: 12px;
      color: #555;
      font-style: italic;
      margin-top: 0.04in;
    }
    .meta {
      display: flex;
      justify-content: space-between;
      gap: 0.3in;
      font-size: 11px;
      margin-bottom: 0.22in;
    }
    h1 {
      text-align: center;
      font-size: 16px;
      text-transform: uppercase;
      margin-bottom: 0.24in;
      text-decoration: underline;
      color: #1e3a5f;
    }
    .section {
      margin-bottom: 0.25in;
    }
    .section-title {
      font-size: 12px;
      font-weight: bold;
      color: #1e3a5f;
      border-bottom: 1px solid #9aa8b5;
      padding-bottom: 0.04in;
      margin-bottom: 0.12in;
      text-transform: uppercase;
    }
    .grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 0.12in 0.3in;
    }
    .field {
      font-size: 12px;
      min-height: 0.28in;
      border-bottom: 1px solid #aaa;
      padding-bottom: 0.04in;
    }
    .field strong {
      display: inline-block;
      min-width: 1.35in;
      color: #333;
    }
    .statement {
      font-size: 12px;
      text-align: justify;
      margin: 0.2in 0;
    }
    .signature-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 0.5in;
      margin-top: 0.4in;
    }
    .signature-line {
      border-top: 1px solid #333;
      padding-top: 0.06in;
      font-size: 11px;
      margin-top: 0.4in;
    }
    .note {
      font-size: 11px;
      color: #444;
      border: 1px solid #c9d3dc;
      background-color: #f8fafc;
      padding: 0.12in;
      margin-top: 0.3in;
      border-radius: 4px;
    }
    .print-button {
      display: block;
      margin: 0.2in auto 0.4in auto;
      padding: 0.15in 0.3in;
      background: #1e3a5f;
      color: white;
      border: none;
      border-radius: 4px;
      font-size: 14px;
      font-weight: bold;
      cursor: pointer;
      text-align: center;
      max-width: 2.5in;
    }
    .print-button:hover {
      background: #152d4a;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="no-print">
      <button class="print-button" onclick="window.print()">Print / Save as PDF</button>
    </div>

    <div class="letterhead" style="text-align: center; border-bottom: 2px solid #1e3a8a; padding-bottom: 10px; margin-bottom: 20px;">
      <img src="${window.location.origin}/HTULH.png" alt="Ho Technical University Letterhead" style="max-width: 100%; height: auto; max-height: 100px; object-fit: contain;" />
    </div>

    <div class="meta">
      <div><strong>Date Issued:</strong> ${T(r)}</div>
      <div><strong>Form:</strong> Company Acceptance</div>
    </div>

    <h1>Company Acceptance Form</h1>

    <div class="section">
      <div class="section-title">Student Details</div>
      <div class="grid">
        <div class="field"><strong>Name:</strong> ${p(e.studentName)}</div>
        <div class="field"><strong>Student ID:</strong> ${p(e.studentId)}</div>
        <div class="field"><strong>Department:</strong> ${p(e.department)}</div>
        <div class="field"><strong>Level:</strong> ${p(e.level)}</div>
      </div>
    </div>

    <div class="section">
      <div class="section-title">Company Details</div>
      <div class="grid">
        <div class="field"><strong>Company:</strong> ${p(e.companyName)}</div>
        <div class="field"><strong>Department/Unit:</strong> </div>
        <div class="field"><strong>Address:</strong> ${p(e.companyAddress)}</div>
        <div class="field"><strong>Phone/Email:</strong> </div>
      </div>
    </div>

    <div class="section">
      <div class="section-title">Attachment Period</div>
      <div class="grid">
        <div class="field"><strong>Start Date:</strong> ${p(e.startDate)}</div>
        <div class="field"><strong>End Date:</strong> ${p(e.endDate)}</div>
      </div>
    </div>

    <p class="statement">
      We confirm that the company named above accepts the student for industrial attachment.
      The student will be assigned suitable duties and supervised during the stated period.
    </p>

    <div class="section">
      <div class="section-title">Workplace Supervisor</div>
      <div class="grid">
        <div class="field"><strong>Name:</strong> </div>
        <div class="field"><strong>Job Title:</strong> </div>
        <div class="field"><strong>Email:</strong> </div>
        <div class="field"><strong>Phone:</strong> </div>
      </div>
    </div>

    <div class="signature-grid">
      <div class="signature-line">Workplace Supervisor Signature / Date</div>
      <div class="signature-line">Company Stamp</div>
    </div>

    <div class="note">
      <strong>Note:</strong> After signing, the student should scan or photograph this form and upload it in the IAMS Documents page.
    </div>
  </div>
</body>
</html>
  `,a=new Blob([n],{type:"text/html;charset=utf-8"}),s=URL.createObjectURL(a);return window.open(s,"_blank")?(setTimeout(()=>URL.revokeObjectURL(s),3e4),!0):(console.error("Popup blocked — could not open company acceptance form"),URL.revokeObjectURL(s),!1)}function ye(e,i){var a,s,d,c;const r=e.confirmed_start_date??((a=e.internship)==null?void 0:a.confirmed_start_date)??((s=e.internship)==null?void 0:s.start_date)??e.start_date??e.proposed_start_date??((d=e.academic_term)==null?void 0:d.start_date)??((c=e.term)==null?void 0:c.start_date)??void 0;if(r)return r;const n=B(e,i);return(n==null?void 0:n.internshipStart)??(n==null?void 0:n.start_date)??(n==null?void 0:n.internship_start)}function je(e,i){var a,s,d,c;const r=e.confirmed_end_date??((a=e.internship)==null?void 0:a.confirmed_end_date)??((s=e.internship)==null?void 0:s.end_date)??e.end_date??e.proposed_end_date??((d=e.academic_term)==null?void 0:d.end_date)??((c=e.term)==null?void 0:c.end_date)??void 0;if(r)return r;const n=B(e,i);return(n==null?void 0:n.internshipEnd)??(n==null?void 0:n.end_date)??(n==null?void 0:n.internship_end)}function B(e,i){var n,a;if(!i||i.length===0)return;const r=e.academic_term_id??((n=e.academic_term)==null?void 0:n.id)??e.term_id??((a=e.term)==null?void 0:a.id);if(r!=null)return i.find(s=>String(s.id)===String(r))}function we(e){if(!e)return;const i=te(e);return i==="—"?void 0:i}function Se(e,i){var n;const r=((n=e.student)==null?void 0:n.department)??e.department;if(typeof r=="string"&&r.trim())return r;if(r&&typeof r=="object"){const a=r.name??r.department_name;if(typeof a=="string"&&a.trim())return a}return i}function Ne({isOpen:e,onClose:i,onSuccess:r,applicationId:n,companyName:a,studentName:s,studentId:d,department:c,level:h,companyAddress:L,proposedStartDate:v,proposedEndDate:y}){const[b,W]=l.useState(""),[x,q]=l.useState(""),[j,J]=l.useState(""),[w,Y]=l.useState(""),[D,G]=l.useState(v??""),[_,V]=l.useState(y??""),[S,K]=l.useState(""),[N,X]=l.useState(""),[f,z]=l.useState(null),[u,P]=l.useState(null),[g,F]=l.useState(!1),[C,E]=l.useState(!1),U=l.useRef(!1),A=b.trim()&&x.trim()&&j.trim()&&w.trim()&&D&&_&&S.trim(),Q=()=>{ge({studentName:s??"Student",studentId:d??"",department:c??"",level:h??"",companyName:a,companyAddress:L,startDate:v,endDate:y})||m.error("Please allow popups to download the company acceptance form.")},Z=async o=>{var I,R;if(!((I=o.target.files)!=null&&I[0]))return;const $=o.target.files[0];if($.size>10*1024*1024){m.error("File size exceeds 10MB limit");return}z($),P(null),F(!0);try{const k=await M.uploadFile($,"iams/acceptance-forms");k.success&&((R=k.data)!=null&&R.url)?(P(k.data.url),m.success("File uploaded successfully")):(m.error(k.message??"Upload failed — you can still submit without the file"),z(null))}catch{m.error("Upload failed — you can still submit without the file"),z(null)}finally{F(!1)}},ee=async()=>{if(!U.current){if(!A){m.error("Please fill in all required fields");return}if(!f){m.error("Please upload the signed acceptance form");return}U.current=!0,E(!0);try{const o=await M.submitCompanyAcceptance(n,{industry_supervisor_name:b,industry_supervisor_title:x,industry_supervisor_email:j,industry_supervisor_phone:w,confirmed_start_date:D,confirmed_end_date:_,student_role:S,placement_department:N,acceptance_notes:`Company accepted. Student role: ${S}${N?` in ${N}`:""}. Supervisor: ${b} (${x}).`,acceptance_form_url:u??void 0});o.success?(m.success("Company acceptance submitted successfully! Your internship is now active."),r({name:b,email:j,phone:w,title:x}),i()):m.error(o.message??"Failed to submit acceptance")}catch(o){console.error("Submission error:",o),m.error("An error occurred while submitting")}finally{U.current=!1,E(!1)}}};return e?t.jsx("div",{className:"fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4",onClick:i,children:t.jsxs("div",{className:"bg-card border border-border rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl",onClick:o=>o.stopPropagation(),children:[t.jsxs("div",{className:"sticky top-0 bg-card border-b border-border p-6 flex items-center justify-between",children:[t.jsxs("div",{children:[t.jsx("h2",{style:{fontSize:"1.3rem"},className:"font-bold",children:"Company Acceptance Form"}),t.jsx("p",{className:"text-muted-foreground mt-1",style:{fontSize:"0.85rem"},children:"Fill in company details and upload the signed acceptance form"})]}),t.jsxs("div",{className:"flex items-center gap-2",children:[t.jsxs("button",{onClick:Q,className:"px-3 py-2 border border-primary text-primary rounded-lg hover:bg-primary/5 font-medium flex items-center gap-2",style:{fontSize:"0.8rem"},children:[t.jsx(ie,{className:"w-4 h-4"}),"Download Form"]}),t.jsx("button",{onClick:i,className:"p-1 rounded-md hover:bg-accent",children:t.jsx(ne,{className:"w-5 h-5"})})]})]}),t.jsxs("div",{className:"p-6 space-y-6",children:[t.jsxs("div",{className:"bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800 rounded-xl p-4",children:[t.jsxs("p",{className:"text-sm text-blue-700 dark:text-blue-300",children:[t.jsx("strong",{children:"Company:"})," ",a]}),v&&t.jsxs("p",{className:"text-sm text-blue-700 dark:text-blue-300 mt-1",children:[t.jsx("strong",{children:"Proposed Period:"})," ",v,y&&` to ${y}`]})]}),t.jsxs("div",{className:"space-y-4",children:[t.jsx("h3",{style:{fontSize:"0.95rem"},className:"font-semibold",children:"Workplace Supervisor Details"}),t.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[t.jsxs("div",{children:[t.jsx("label",{style:{fontSize:"0.8rem"},className:"block text-muted-foreground font-medium mb-1",children:"Supervisor Name *"}),t.jsx("input",{type:"text",value:b,onChange:o=>W(o.target.value),placeholder:"e.g., John Appiah",className:"w-full px-3 py-2 border border-border rounded-lg bg-background",style:{fontSize:"0.85rem"}})]}),t.jsxs("div",{children:[t.jsx("label",{style:{fontSize:"0.8rem"},className:"block text-muted-foreground font-medium mb-1",children:"Job Title *"}),t.jsx("input",{type:"text",value:x,onChange:o=>q(o.target.value),placeholder:"e.g., Senior Engineer",className:"w-full px-3 py-2 border border-border rounded-lg bg-background",style:{fontSize:"0.85rem"}})]})]}),t.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[t.jsxs("div",{children:[t.jsx("label",{style:{fontSize:"0.8rem"},className:"block text-muted-foreground font-medium mb-1",children:"Email *"}),t.jsx("input",{type:"email",value:j,onChange:o=>J(o.target.value),placeholder:"supervisor@company.com",className:"w-full px-3 py-2 border border-border rounded-lg bg-background",style:{fontSize:"0.85rem"}})]}),t.jsxs("div",{children:[t.jsx("label",{style:{fontSize:"0.8rem"},className:"block text-muted-foreground font-medium mb-1",children:"Phone *"}),t.jsx("input",{type:"tel",value:w,onChange:o=>Y(o.target.value),placeholder:"e.g., +233 50 123 4567",className:"w-full px-3 py-2 border border-border rounded-lg bg-background",style:{fontSize:"0.85rem"}})]})]})]}),t.jsxs("div",{className:"space-y-4",children:[t.jsx("h3",{style:{fontSize:"0.95rem"},className:"font-semibold",children:"Confirmed Attachment Period"}),t.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[t.jsxs("div",{children:[t.jsx("label",{style:{fontSize:"0.8rem"},className:"block text-muted-foreground font-medium mb-1",children:"Start Date *"}),t.jsx(H,{value:D,onChange:G})]}),t.jsxs("div",{children:[t.jsx("label",{style:{fontSize:"0.8rem"},className:"block text-muted-foreground font-medium mb-1",children:"End Date *"}),t.jsx(H,{value:_,onChange:V})]})]})]}),t.jsxs("div",{className:"space-y-4",children:[t.jsx("h3",{style:{fontSize:"0.95rem"},className:"font-semibold",children:"Placement Details"}),t.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[t.jsxs("div",{children:[t.jsx("label",{style:{fontSize:"0.8rem"},className:"block text-muted-foreground font-medium mb-1",children:"Student Role / Position *"}),t.jsx("input",{type:"text",value:S,onChange:o=>K(o.target.value),placeholder:"e.g., Software Developer Intern",className:"w-full px-3 py-2 border border-border rounded-lg bg-background",style:{fontSize:"0.85rem"}})]}),t.jsxs("div",{children:[t.jsx("label",{style:{fontSize:"0.8rem"},className:"block text-muted-foreground font-medium mb-1",children:"Department / Unit"}),t.jsx("input",{type:"text",value:N,onChange:o=>X(o.target.value),placeholder:"e.g., IT Department",className:"w-full px-3 py-2 border border-border rounded-lg bg-background",style:{fontSize:"0.85rem"}})]})]})]}),t.jsxs("div",{className:"space-y-4",children:[t.jsx("h3",{style:{fontSize:"0.95rem"},className:"font-semibold",children:"Upload Signed Acceptance Form"}),t.jsx("p",{className:"text-muted-foreground text-sm",children:"Upload a scan or photo of the signed acceptance form from the company. Max 10MB (PDF or Image)."}),t.jsx("div",{className:`border-2 border-dashed rounded-xl p-6 text-center transition-colors ${u?"border-emerald-400 bg-emerald-50 dark:bg-emerald-950/20":"border-border hover:bg-muted/30"}`,children:t.jsxs("label",{className:`flex flex-col items-center gap-2 ${g?"cursor-wait":"cursor-pointer"}`,children:[g?t.jsx(re,{className:"w-8 h-8 text-primary animate-spin"}):u?t.jsx(se,{className:"w-8 h-8 text-emerald-600"}):t.jsx(oe,{className:"w-8 h-8 text-muted-foreground"}),t.jsx("span",{className:"text-sm font-medium",children:g?"Uploading...":u?(f==null?void 0:f.name)??"File uploaded":"Click to select file or drag & drop"}),u&&t.jsx("span",{className:"text-xs text-emerald-600",children:"Uploaded successfully"}),f&&!u&&!g&&t.jsxs("span",{className:"text-xs text-muted-foreground",children:[(f.size/1024/1024).toFixed(2)," MB"]}),t.jsx("input",{type:"file",onChange:Z,accept:"image/*,.pdf",disabled:g,className:"hidden"})]})})]}),t.jsxs("div",{className:"bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded-xl p-4 flex gap-3",children:[t.jsx(ae,{className:"w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5"}),t.jsxs("div",{className:"text-sm text-amber-700 dark:text-amber-300",children:[t.jsx("p",{className:"font-medium",children:"Before submitting:"}),t.jsxs("ul",{className:"list-disc list-inside mt-1 space-y-0.5 text-xs",children:[t.jsx("li",{children:"Ensure all supervisor details are correct and match the company records"}),t.jsx("li",{children:"Confirm the attachment dates with your supervisor"}),t.jsx("li",{children:"Have the company sign and scan/photo the acceptance form"})]})]})]})]}),t.jsxs("div",{className:"sticky bottom-0 bg-card border-t border-border p-6 flex gap-3 justify-end",children:[t.jsx("button",{onClick:i,disabled:C,className:"px-6 py-2 border border-border rounded-lg hover:bg-accent font-medium",style:{fontSize:"0.85rem"},children:"Cancel"}),t.jsx("button",{onClick:ee,disabled:!A||!u||C||g,className:"px-6 py-2 bg-primary text-primary-foreground rounded-lg hover:opacity-90 disabled:opacity-50 font-medium",style:{fontSize:"0.85rem"},children:g?"Uploading file...":C?"Submitting...":"Submit Acceptance"})]})]})}):null}export{Ne as C,ye as a,ge as d,we as f,je as g,ve as o,Se as r};
