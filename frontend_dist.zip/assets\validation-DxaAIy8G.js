function r(t,i=2){return!t||typeof t!="string"?"U":t.split(" ").map(e=>e[0]).join("").slice(0,i).toUpperCase()}export{r as g};
