import{V as Ve,a7 as l,a5 as t,X as Ie,U as De,F as T,ad as i,i as A,N as _,ag as Ke,w as Ze,y as je,n as Se}from"./index-CRzkC7MU.js";import{C as Qe,r as M,d as et,f as D,g as X,a as G,o as tt}from"./company-acceptance-modal-Cvf1e1z7.js";import{a as ke}from"./print-fallback-DuorPCeU.js";import{e as nt}from"./logbook-export-BAj8vwwm.js";import{S as _e}from"./send-CK3dYEqK.js";import{C as st}from"./clock-DFQ7aUDK.js";import"./date-utils-cNwPtUwz.js";import"./date-picker-DckxDeEX.js";import"./utils-gPd2mQ4j.js";import"./clsx-B-dksMZM.js";/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const at=[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}]],it=Ve("file",at),ot="iams_template_overrides",rt="insurance-letter";function lt(){try{const s=localStorage.getItem(ot);if(!s)return null;const e=JSON.parse(s);return(e==null?void 0:e[rt])??null}catch{return null}}function dt(s){const C=new Date().toLocaleDateString("en-GB",{year:"numeric",month:"long",day:"numeric"}),x=lt(),I=(x==null?void 0:x.signatureUrl)||s.signatureUrl,h=(x==null?void 0:x.coordinatorName)||s.coordinatorName||"Mrs. Stella A. B. Adzika",v=`
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Indemnity Form</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    body {
      font-family: 'Times New Roman', Times, Georgia, serif;
      line-height: 1.5;
      color: #000;
      background: white;
      padding: 0.3in 0.5in;
    }
    @media print {
      body {
        margin: 0;
        padding: 0.3in 0.4in;
        background: white;
      }
      .no-print {
        display: none !important;
      }
    }
    .container {
      max-width: 8.5in;
      margin: 0 auto;
    }
    .print-button {
      background: #1e3a8a;
      color: white;
      border: none;
      padding: 8px 16px;
      border-radius: 4px;
      font-size: 14px;
      cursor: pointer;
      margin-bottom: 0.2in;
      display: inline-block;
    }
    .letterhead {
      text-align: center;
      border-bottom: 2px solid #000;
      padding-bottom: 5px;
      margin-bottom: 15px;
    }
    .title {
      text-align: center;
      font-size: 16pt;
      font-weight: bold;
      letter-spacing: 2px;
      margin-bottom: 20px;
      text-decoration: underline;
    }
    .paragraph {
      font-size: 11pt;
      text-align: justify;
      margin-bottom: 15px;
      text-indent: 0.25in;
    }
    .underline-field {
      border-bottom: 1px dotted #000;
      display: inline-block;
      padding: 0 4px;
      font-weight: bold;
    }
    .sign-section {
      margin-top: 15px;
      font-size: 10pt;
    }
    .sign-block {
      margin-bottom: 15px;
      page-break-inside: avoid;
    }
    .sign-title {
      font-weight: bold;
      text-decoration: underline;
      margin-bottom: 6px;
    }
    .sign-row {
      margin-bottom: 4px;
      display: flex;
      align-items: flex-end;
    }
    .field-label {
      width: 100px;
      flex-shrink: 0;
    }
    .field-line {
      flex-grow: 1;
      border-bottom: 1px dotted #000;
      padding-bottom: 2px;
      position: relative;
    }
    .signature-img {
      position: absolute;
      bottom: 2px;
      left: 10px;
      max-height: 45px;
    }
    .right-sign-line {
      width: 2.2in;
      text-align: center;
      margin-left: 20px;
      border-top: 1px solid #000;
      margin-top: 25px;
      font-weight: bold;
      font-size: 9.5pt;
    }
    .footer-note {
      border-top: 1px solid #ccc;
      margin-top: 20px;
      padding-top: 8px;
      font-size: 8.5pt;
      font-style: italic;
      color: #444;
      text-align: center;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="no-print" style="text-align: center;">
      <button class="print-button" onclick="window.print()">Print / Save as PDF</button>
    </div>
    
    <div class="letterhead">
      <img src="${window.location.origin}/HTULH.png" alt="HTU Letterhead" style="max-width: 100%; height: auto; max-height: 90px; object-fit: contain;" />
    </div>
    
    <div class="title">INDEMNITY FORM</div>
    
    <div class="paragraph" style="text-indent: 0;">
      I, <span class="underline-field" style="min-width: 250px; text-align: center; display: inline-block;">${s.studentName}</span> of <span class="underline-field" style="min-width: 250px; text-align: center; display: inline-block;">Ho Technical University</span><br/>
      <span style="font-size: 8.5pt; color: #555; display: inline-block; width: 250px; text-align: center; margin-top: 2px; font-style: italic;">(Name of Student)</span>
      <span style="font-size: 8.5pt; color: #555; display: inline-block; width: 250px; text-align: center; margin-top: 2px; font-style: italic;">(Institution)</span>
    </div>
    
    <div class="paragraph">
      declare that I accept to undertake industrial attachment training with <span class="underline-field">${s.companyName}</span> (hereinafter, referred to as <span class="underline-field">${s.companyName}</span>) - <span class="underline-field">${s.companyAddress||"—"}</span>, from <span class="underline-field">${s.startDate||"—"}</span> to <span class="underline-field">${s.endDate||"—"}</span>. During this period, <span class="underline-field">${s.companyName}</span> will not be responsible for the payment of salary or any other allowance or fringe benefit(s) otherwise specified.
    </div>
    
    <div class="paragraph">
      I, further, declare that <span class="underline-field">${s.companyName}</span> shall not be held liable whatsoever or under the Workmen's Compensation Law (1987) PNDC 187 for any loss, damage or injury that I may suffer if the loss, damage or injury was caused by any act of omission, arising from my negligence or an "Act of God".
    </div>
    
    <div class="sign-section">
      <!-- Student block -->
      <div class="sign-block" style="display: flex; justify-content: space-between;">
        <div style="width: 60%;">
          <p class="sign-title">SIGNED by the said Student:</p>
          <p style="margin-bottom: 8px; font-style: italic; color: #555;">in the presence of (Student's Witness):</p>
          <div class="sign-row">
            <span class="field-label">Name:</span>
            <span class="field-line"></span>
          </div>
          <div class="sign-row" style="margin-top: 8px;">
            <span class="field-label">Date:</span>
            <span class="field-line" style="width: 150px; flex-grow: 0;"></span>
            <span style="margin-left: 10px; margin-right: 5px;">Signature:</span>
            <span class="field-line"></span>
          </div>
        </div>
        <div style="display: flex; flex-direction: column; justify-content: flex-end; align-items: center;">
          <div class="right-sign-line">Signature of Student</div>
        </div>
      </div>
      
      <!-- HTU block -->
      <div class="sign-block" style="display: flex; justify-content: space-between;">
        <div style="width: 60%; space-y-2;">
          <p class="sign-title">SIGNED on behalf of the HTU:</p>
          <div class="sign-row" style="margin-top: 6px;">
            <span class="field-label">Name:</span>
            <span class="field-line">${h}</span>
          </div>
          <div class="sign-row" style="margin-top: 6px;">
            <span class="field-label">Designation:</span>
            <span class="field-line">Industrial Liaison Officer</span>
          </div>
          <div class="sign-row" style="margin-top: 6px;">
            <span class="field-label">Signature:</span>
            <span class="field-line" style="min-height: 25px;">
              ${I?`<img class="signature-img" src="${I}" alt="Signature" />`:""}
            </span>
          </div>
          <div class="sign-row" style="margin-top: 6px;">
            <span class="field-label">Date:</span>
            <span class="field-line">${C}</span>
          </div>
        </div>
        <div style="display: flex; flex-direction: column; justify-content: flex-end; align-items: center;">
          <div class="right-sign-line">Industrial Liaison Office Stamp</div>
        </div>
      </div>
      
      <!-- Company block -->
      <div class="sign-block" style="display: flex; justify-content: space-between;">
        <div style="width: 60%;">
          <p class="sign-title">SIGNED on behalf of ${s.companyName}:</p>
          <p style="margin-bottom: 8px; font-style: italic; color: #555;">in the presence of (Witness):</p>
          <div class="sign-row">
            <span class="field-label">Name:</span>
            <span class="field-line"></span>
          </div>
          <div class="sign-row" style="margin-top: 8px;">
            <span class="field-label">Date:</span>
            <span class="field-line" style="width: 150px; flex-grow: 0;"></span>
            <span style="margin-left: 10px; margin-right: 5px;">Signature:</span>
            <span class="field-line"></span>
          </div>
        </div>
        <div style="display: flex; flex-direction: column; justify-content: flex-end; align-items: center;">
          <div class="right-sign-line">Signature Rep:</div>
        </div>
      </div>
    </div>
    
    <div class="footer-note">
      NB: Please scan this completed form and email to <strong style="color: #1e3a8a;">industrialliaison@htu.edu.gh</strong> or WhatsApp to <strong style="color: #1e3a8a;">0244 055762</strong> at the start of attachment.
    </div>
  </div>
</body>
</html>
  `;try{const r=window.open("","_blank");r?(r.document.open(),r.document.write(v),r.document.close()):ke(v,"Indemnity Form")}catch(r){console.warn("Failed to open Indemnity Form window, displaying in-app modal instead",r),ke(v,"Indemnity Form")}}function ct({isOpen:s,onClose:e,onSuccess:C,title:x,description:I,allowedTypes:h=[".pdf",".doc",".docx"],maxSizeMB:v=10}){const[r,N]=l.useState(null),[j,w]=l.useState(!1),[F,P]=l.useState(0);if(!s)return null;const $=b=>{if(b.target.files&&b.target.files[0]){const m=b.target.files[0];if(m.size/(1024*1024)>v){i.error(`File size exceeds the ${v}MB limit.`);return}const E=m.name.substring(m.name.lastIndexOf(".")).toLowerCase();if(h.length>0&&!h.includes(E)&&!h.some(u=>m.type.includes(u.replace(".","")))){i.error(`Invalid file type. Allowed formats: ${h.join(", ")}`);return}N(m)}},y=async()=>{var b;if(!r){i.error("Please select a file to upload.");return}w(!0),P(0);try{const m=await apiClient.uploadFile(r,"iams/student-documents");m.success&&((b=m.data)!=null&&b.url)?(i.success(`${r.name} uploaded successfully!`),C(m.data.url),N(null),e()):i.error(m.message??"Upload failed. Please try again.")}catch(m){console.error("Upload error:",m),i.error("An unexpected error occurred during upload.")}finally{w(!1)}};return t.jsx("div",{className:"fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4",onClick:e,children:t.jsxs("div",{className:"bg-card border border-border rounded-2xl w-full max-w-md overflow-hidden shadow-2xl animate-in fade-in zoom-in-95 duration-200",onClick:b=>b.stopPropagation(),children:[t.jsxs("div",{className:"p-6 border-b border-border flex items-center justify-between",children:[t.jsxs("div",{children:[t.jsx("h2",{className:"text-lg font-bold text-foreground",children:x}),t.jsx("p",{className:"text-muted-foreground text-xs mt-1",children:I})]}),t.jsx("button",{onClick:e,className:"p-1 rounded-md hover:bg-accent text-muted-foreground transition-colors",children:t.jsx(Ie,{className:"w-5 h-5"})})]}),t.jsx("div",{className:"p-6 space-y-6",children:j?t.jsxs("div",{className:"space-y-4 py-4",children:[t.jsxs("div",{className:"flex items-center gap-3",children:[t.jsx(T,{className:"w-8 h-8 text-primary animate-pulse"}),t.jsxs("div",{className:"flex-1 min-w-0",children:[t.jsx("p",{className:"text-sm font-medium truncate text-foreground",children:r==null?void 0:r.name}),t.jsx("p",{className:"text-xs text-muted-foreground mt-0.5",children:"Uploading..."})]}),t.jsxs("span",{className:"text-sm font-semibold text-primary",children:[F,"%"]})]}),t.jsx("div",{className:"w-full bg-secondary rounded-full h-2 overflow-hidden",children:t.jsx("div",{className:"bg-primary h-full transition-all duration-100 ease-out",style:{width:`${F}%`}})})]}):t.jsx("div",{className:"border-2 border-dashed border-border rounded-xl p-6 text-center hover:bg-muted/30 transition-colors",children:t.jsxs("label",{className:"cursor-pointer flex flex-col items-center gap-2",children:[t.jsx(De,{className:"w-8 h-8 text-muted-foreground"}),t.jsx("span",{className:"text-sm font-medium text-foreground",children:r?r.name:"Click to select file or drag & drop"}),r?t.jsxs("span",{className:"text-xs text-muted-foreground",children:[(r.size/1024/1024).toFixed(2)," MB"]}):t.jsxs("span",{className:"text-xs text-muted-foreground",children:["Supported formats: ",h.join(", ")," (Max ",v,"MB)"]}),t.jsx("input",{type:"file",onChange:$,accept:h.join(","),className:"hidden"})]})})}),t.jsxs("div",{className:"p-6 border-t border-border flex gap-3 justify-end bg-muted/20",children:[t.jsx("button",{onClick:e,disabled:j,className:"px-4 py-2 border border-border rounded-lg hover:bg-accent font-medium text-sm text-foreground transition-colors disabled:opacity-50",children:"Cancel"}),t.jsx("button",{onClick:y,disabled:!r||j,className:"px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:opacity-90 disabled:opacity-50 font-medium text-sm transition-opacity flex items-center gap-1.5",children:j?"Uploading...":"Upload Document"})]})]})})}function mt({isOpen:s,onClose:e,applicationId:C,initialName:x="",initialEmail:I="",initialPhone:h="",studentName:v="Student",companyName:r="Company"}){const[N,j]=l.useState(x),[w,F]=l.useState(I),[P,$]=l.useState(h),[y,b]=l.useState(!1),[m,R]=l.useState(!1),E=async()=>{if(!N.trim()||!w.trim()){i.error("Please provide supervisor name and email.");return}b(!0);try{const u=await _.requestMagicLink(w,{role:"industry_supervisor",name:N,phone:P||void 0,application_id:C,company_name:r,student_name:v});u.success?(R(!0),i.success(`Magic link sent to ${w}`),setTimeout(()=>{e(),R(!1),j(""),F(""),$("")},2e3)):i.error(u.message??"Failed to send magic link.")}catch(u){console.error("Error sending magic link:",u),i.error("An error occurred while sending the link.")}finally{b(!1)}};return s?t.jsx("div",{className:"fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4",children:t.jsxs("div",{className:"bg-background rounded-2xl shadow-xl max-w-md w-full p-6 space-y-4",children:[t.jsxs("div",{className:"flex items-center justify-between",children:[t.jsx("h2",{className:"text-xl font-bold",children:"Invite Supervisor"}),t.jsx("button",{onClick:e,disabled:y,className:"p-1 hover:bg-accent rounded-lg transition-colors disabled:opacity-50",children:t.jsx(Ie,{className:"w-5 h-5"})})]}),m?t.jsxs("div",{className:"bg-emerald-50 border border-emerald-200 rounded-lg p-4 text-center space-y-2",children:[t.jsx(A,{className:"w-8 h-8 text-emerald-600 mx-auto"}),t.jsx("p",{className:"font-semibold text-emerald-900 text-sm",children:"Link Sent Successfully!"}),t.jsxs("p",{className:"text-xs text-emerald-700",children:[N," will receive an email with access link. It expires in 30 days."]})]}):t.jsxs("div",{className:"space-y-4",children:[t.jsx("p",{className:"text-sm text-muted-foreground",children:"Send a secure access link to your supervisor so they can evaluate your internship performance."}),t.jsxs("div",{className:"space-y-3",children:[t.jsxs("div",{children:[t.jsx("label",{className:"text-xs font-semibold text-muted-foreground block mb-1",children:"Supervisor Name *"}),t.jsx("input",{type:"text",value:N,onChange:u=>j(u.target.value),placeholder:"e.g., John Doe",disabled:y,className:"w-full px-3 py-2.5 border border-border rounded-lg bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary disabled:opacity-50"})]}),t.jsxs("div",{children:[t.jsx("label",{className:"text-xs font-semibold text-muted-foreground block mb-1",children:"Email Address *"}),t.jsx("input",{type:"email",value:w,onChange:u=>F(u.target.value),placeholder:"supervisor@company.com",disabled:y,className:"w-full px-3 py-2.5 border border-border rounded-lg bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary disabled:opacity-50"})]}),t.jsxs("div",{children:[t.jsx("label",{className:"text-xs font-semibold text-muted-foreground block mb-1",children:"Phone Number (Optional)"}),t.jsx("input",{type:"tel",value:P,onChange:u=>$(u.target.value),placeholder:"+233 XX XXX XXXX",disabled:y,className:"w-full px-3 py-2.5 border border-border rounded-lg bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary disabled:opacity-50"})]})]}),t.jsx("div",{className:"bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800 rounded-lg p-3",children:t.jsxs("p",{className:"text-xs text-blue-700 dark:text-blue-300",children:[t.jsx("span",{className:"font-semibold",children:"Note:"})," The supervisor will receive a secure magic link via email and can access the system for 30 days."]})}),t.jsxs("div",{className:"flex gap-2 pt-2",children:[t.jsx("button",{onClick:e,disabled:y,className:"flex-1 px-4 py-2.5 border border-border rounded-lg hover:bg-accent font-medium text-sm transition-colors disabled:opacity-50",children:"Cancel"}),t.jsxs("button",{onClick:E,disabled:y||!N.trim()||!w.trim(),className:"flex-1 px-4 py-2.5 bg-primary text-primary-foreground rounded-lg hover:opacity-90 font-medium text-sm flex items-center justify-center gap-2 transition-all disabled:opacity-50 disabled:cursor-not-allowed",children:[t.jsx(_e,{className:"w-4 h-4"}),y?"Sending...":"Send Link"]})]})]})]})}):null}function kt(){var te,ne,se,ae,ie,oe,re,le,de,ce,me,pe,ue,ge;const{user:s}=Ke(),[e,C]=l.useState(null),[x,I]=l.useState(null),[h,v]=l.useState("Company"),[r,N]=l.useState([]),[j,w]=l.useState([]),[F,P]=l.useState(!1),[$,y]=l.useState(!1),[b,m]=l.useState(!1),[R,E]=l.useState(!1),[u,V]=l.useState(()=>{try{return localStorage.getItem("iams_final_report_name")}catch{return null}}),[K,Z]=l.useState(()=>{try{return localStorage.getItem("iams_final_report_url")}catch{return null}}),Y=()=>{_.getTerms().then(n=>{n.success&&N(n.data)}),_.getTemplates().then(n=>{if(n.success){const a=n.data.filter(o=>{var f;const d=["placement-letter","acceptance-form","insurance-letter","logbook-template"].includes(o.slug??o.id);let c=!1;try{const p=o.visible_to?JSON.parse(o.visible_to):o.visibleTo;c=Array.isArray(p)?p.includes("Student"):!1}catch{c=((f=o.visibleTo)==null?void 0:f.includes("Student"))||!1}const g=o.status==="Active";return!d&&c&&g});w(a)}}),_.getApplications().then(n=>{if(n.success&&n.data.length>0){const a=[...n.data].sort((o,d)=>(d.created_at??"")>(o.created_at??"")?1:-1);C(a[0])}}),_.getInternships().then(n=>{var a;if(n.success&&n.data.length>0){const d=[...n.data].sort((c,g)=>(g.created_at??"")>(c.created_at??"")?1:-1)[0];I(String(d.id)),v(((a=d.company)==null?void 0:a.name)||d.companyName||"Company"),d.final_report_url&&(Z(d.final_report_url),V(d.final_report_name||"Final Internship Report"))}})};l.useEffect(()=>{Y()},[]);const[z,Ce]=l.useState(""),[H,Fe]=l.useState(""),[Q,Pe]=l.useState(""),[Ue,Le]=l.useState(""),[Te,$e]=l.useState(!1),U=!!(e!=null&&e.status&&["approved","active","completed","company accepted","company_accepted"].includes(e.status.toLowerCase())),O=((te=e==null?void 0:e.status)==null?void 0:te.toLowerCase())==="active",L=((ne=e==null?void 0:e.status)==null?void 0:ne.toLowerCase())==="completed",W=((se=e==null?void 0:e.status)==null?void 0:se.toLowerCase())==="approved",Re=()=>{var d,c,g,f,p,S,k,q;if(!e)return;const n=typeof((d=e.company)==null?void 0:d.name)=="string"?e.company.name:typeof e.companyName=="string"?e.companyName:"Company",a=typeof((c=e.company)==null?void 0:c.address)=="string"?e.company.address:void 0,o=typeof((f=(g=e.academic_supervisor)==null?void 0:g.user)==null?void 0:f.name)=="string"?e.academic_supervisor.user.name:typeof e.supervisorAssigned=="string"?e.supervisorAssigned:void 0;tt({studentName:((S=(p=e.student)==null?void 0:p.user)==null?void 0:S.name)??e.studentName??(s==null?void 0:s.name)??"Student",studentId:((k=e.student)==null?void 0:k.student_id)??e.studentId??(s==null?void 0:s.studentId)??"—",department:M(e,(s==null?void 0:s.department)??"—"),level:((q=e.student)==null?void 0:q.level)??e.level??"—",companyName:n,companyAddress:a,supervisorName:o,startDate:D(G(e,r)),endDate:D(X(e,r))})},Ee=async()=>{var a,o,d,c,g,f;if(!e){i.error("No active application data found to generate form.");return}E(!0);const n=i.loading("Preparing your acceptance form download...");try{const p=typeof((a=e.company)==null?void 0:a.name)=="string"?e.company.name:typeof e.companyName=="string"?e.companyName:"Company",S=typeof((o=e.company)==null?void 0:o.address)=="string"?e.company.address:void 0;await et({studentName:((c=(d=e.student)==null?void 0:d.user)==null?void 0:c.name)??e.studentName??(s==null?void 0:s.name)??"Student",studentId:((g=e.student)==null?void 0:g.student_id)??e.studentId??(s==null?void 0:s.studentId)??"",department:M(e,(s==null?void 0:s.department)??""),level:((f=e.student)==null?void 0:f.level)??e.level??"",companyName:p,companyAddress:S,startDate:D(G(e,r)),endDate:D(X(e,r))}),i.success("Acceptance Form downloaded successfully!",{id:n})}catch(p){console.error("Download pipeline error:",p),i.error("Could not complete document export. Please check application data.",{id:n})}finally{E(!1)}},Oe=async()=>{if(!x){i.error("No active/completed internship found for logbook export.");return}const n=i.loading("Generating logbook export PDF...");try{const a=await _.getInternshipLogbooks(x,{per_page:100});i.dismiss(n),a.success?(nt(h,a.data??[]),i.success("Logbook PDF generated successfully!")):i.error("Failed to load logbook entries.")}catch{i.dismiss(n),i.error("An error occurred while generating PDF.")}},ze=()=>{var o,d,c,g,f,p;if(!e)return;const n=typeof((o=e.company)==null?void 0:o.name)=="string"?e.company.name:typeof e.companyName=="string"?e.companyName:"Company",a=typeof((d=e.company)==null?void 0:d.address)=="string"?e.company.address:typeof e.companyAddress=="string"?e.companyAddress:"—";dt({studentName:((g=(c=e.student)==null?void 0:c.user)==null?void 0:g.name)??(s==null?void 0:s.name)??"Student",studentId:((f=e.student)==null?void 0:f.student_id)??(s==null?void 0:s.studentId)??"—",department:M(e,(s==null?void 0:s.department)??"—"),level:((p=e.student)==null?void 0:p.level)??e.level??"—",companyName:n,companyAddress:a,startDate:D(G(e,r)),endDate:D(X(e,r))})},Me=n=>{var fe,xe,be,he,ye,ve,Ne,we;const a=n.rawTemplate,o=a.body||"",d=((xe=(fe=e==null?void 0:e.student)==null?void 0:fe.user)==null?void 0:xe.name)??(s==null?void 0:s.name)??"Student",c=((be=e==null?void 0:e.student)==null?void 0:be.student_id)??(s==null?void 0:s.studentId)??"—",g=M(e,(s==null?void 0:s.department)??"—"),f=((he=e==null?void 0:e.student)==null?void 0:he.level)??(e==null?void 0:e.level)??"—",p=typeof((ye=e==null?void 0:e.company)==null?void 0:ye.name)=="string"?e.company.name:typeof(e==null?void 0:e.companyName)=="string"?e.companyName:"Company",S=typeof((ve=e==null?void 0:e.company)==null?void 0:ve.address)=="string"?e.company.address:"—",k=typeof((we=(Ne=e==null?void 0:e.academic_supervisor)==null?void 0:Ne.user)==null?void 0:we.name)=="string"?e.academic_supervisor.user.name:typeof(e==null?void 0:e.supervisorAssigned)=="string"?e.supervisorAssigned:"—",q=D(G(e,r))??"—",Be=D(X(e,r))??"—",Xe=o.split("[Student Name]").join(d).split("[Student ID]").join(c).split("[Department]").join(g).split("[Level]").join(f).split("[Company Name]").join(p).split("[Company Address]").join(S).split("[Start Date]").join(q).split("[End Date]").join(Be).split("[Supervisor Name]").join(k).split(`
`).filter(J=>J.trim().length>0).map(J=>`<p style="margin-bottom: 0.15in; text-align: justify;">${J}</p>`).join(`
`),Ge=new Date().toLocaleDateString("en-GB",{year:"numeric",month:"long",day:"numeric"}),Ye=a.has_letterhead||a.hasLetterhead?`
      <div class="letterhead" style="text-align: center; margin-bottom: 0.3in; border-bottom: 2px solid #1e3a8a; padding-bottom: 10px;">
        <img src="${window.location.origin}/HTULH.png" alt="HTU Letterhead" style="max-width: 100%; height: auto; max-height: 100px; object-fit: contain;" />
      </div>
      `:"",We=(a.has_signature||a.hasSignature)&&a.signature_url?`
      <div class="signature-section" style="margin-top: 0.4in; page-break-inside: avoid;">
        <p style="margin-bottom: 0.05in;">Yours faithfully,</p>
        <img src="${a.signature_url}" alt="Signature" style="max-height: 60px; object-fit: contain; display: block; margin-bottom: 0.05in;" />
        <p style="font-weight: bold; border-top: 1px solid #ccc; display: inline-block; padding-top: 2px;">Industrial Liaison Officer</p>
        <p style="font-size: 10pt; color: #555; margin-top: 2px;">Industrial Liaison Office</p>
        <p style="font-size: 10pt; color: #555;">Ho Technical University</p>
      </div>
      `:"",Je=`
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>${a.name}</title>
  <style>
    body {
      font-family: 'Times New Roman', Times, Georgia, serif;
      line-height: 1.6;
      color: #333;
      padding: 0.5in;
      background: white;
    }
    @media print {
      body {
        margin: 1in;
        padding: 0;
      }
      .no-print {
        display: none !important;
      }
    }
    .container {
      max-width: 8.5in;
      margin: 0 auto;
    }
    .print-button {
      background: #1e3a8a;
      color: white;
      border: none;
      padding: 8px 16px;
      border-radius: 4px;
      font-size: 14px;
      cursor: pointer;
      margin-bottom: 0.3in;
      display: inline-block;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="no-print" style="text-align: center;">
      <button class="print-button" onclick="window.print()">Print / Save as PDF</button>
    </div>
    ${Ye}
    <div class="date" style="text-align: right; margin-bottom: 0.2in;">Date: ${Ge}</div>
    <div class="body" style="font-size: 11pt;">
      ${Xe}
    </div>
    ${We}
  </div>
</body>
</html>
    `,B=window.open("","_blank");B?(B.document.open(),B.document.write(Je),B.document.close()):i.error("Popup blocker prevented opening print window.")},Ae=async n=>{if(!x){i.error("No active internship found to attach the report to.");return}const a=i.loading("Submitting final report...");try{const o=await _.submitFinalReport(x,{report_url:n,report_name:"Final Internship Report"});o.success?(V("Final Internship Report"),Z(n),localStorage.setItem("iams_final_report_name","Final Internship Report"),localStorage.setItem("iams_final_report_url",n),i.success("Final report submitted successfully!",{id:a}),Y()):i.error(o.message??"Failed to submit final report record.",{id:a})}catch(o){console.error("Report submission error:",o),i.error("An error occurred during report submission.",{id:a})}},He=[...[{id:"placement-letter",name:"Placement Letter",desc:"Official letter from the university to the company requesting student placement",status:U?"Available":"Pending",canDownload:!!U,canUpload:!1,icon:T},{id:"insurance-letter",name:"Insurance Letter",desc:"Official letter confirming student Group Personal Accident Insurance cover during industrial attachment",status:U?"Available":"Pending",canDownload:!!U,canUpload:!1,icon:Ze},{id:"acceptance-form",name:"Company Acceptance Form",desc:"Form to be signed by the company confirming acceptance of the student. After download, share with your supervisor and invite them to the system.",status:((ae=e==null?void 0:e.status)==null?void 0:ae.toLowerCase())==="company accepted"||((ie=e==null?void 0:e.status)==null?void 0:ie.toLowerCase())==="company_accepted"||O||L?"Uploaded":W?"Action Required":U?"Available":"Pending",canDownload:!!e,canUpload:W,icon:it},{id:"logbook-form",name:"Logbook Form (Manual)",desc:"Printable blank weekly logbook sheet to document activities manually if your industrial supervisor cannot use the digital portal.",status:"Available",canDownload:!0,canUpload:!1,icon:T},{id:"final-report",name:"Final Internship Report",desc:"Your comprehensive final report documenting the internship experience, tasks, and learnings",status:u?"Submitted":O||L?"Not Submitted":"Not Available Yet",canDownload:!!u,canUpload:O||L,icon:T},{id:"logbook-export",name:"Logbook Export (PDF)",desc:"Auto-generated PDF of all your approved logbook entries",status:O||L?"Available":"Pending",canDownload:!!O||!!L,canUpload:!1,icon:T}],...j.map(n=>({id:`custom-${n.slug??n.id}`,name:n.name,desc:n.desc||"Additional document template",status:U?"Available":"Pending",canDownload:!!U,canUpload:!1,icon:T,rawTemplate:n}))],ee=async(n,a,o,d)=>{var f,p,S;if(!n.trim()||!a.trim())return!1;const c=typeof((f=e==null?void 0:e.company)==null?void 0:f.name)=="string"?e.company.name:typeof(e==null?void 0:e.companyName)=="string"?e.companyName:void 0,g=((S=(p=e==null?void 0:e.student)==null?void 0:p.user)==null?void 0:S.name)??(e==null?void 0:e.studentName)??(s==null?void 0:s.name);try{const k=await _.requestMagicLink(a,{role:"industry_supervisor",name:n,phone:o||void 0,job_title:d||void 0,application_id:e==null?void 0:e.id,company_name:c,student_name:g});return k.success?(Ce(n),Fe(a),Pe(o||""),Le(d||""),$e(!0),i.success(`Supervisor invite sent to ${a}!`),!0):(i.error(k.message??"Failed to send supervisor invite."),!1)}catch(k){return console.error("Error sending supervisor invite:",k),i.error("Failed to send supervisor invite."),!1}},qe=n=>{const a={Available:"bg-emerald-100 text-emerald-700",Uploaded:"bg-emerald-100 text-emerald-700",Submitted:"bg-emerald-100 text-emerald-700","Action Required":"bg-red-100 text-red-700","Not Submitted":"bg-amber-100 text-amber-700","Not Available Yet":"bg-gray-100 text-gray-500",Pending:"bg-gray-100 text-gray-500"},o={Available:t.jsx(A,{className:"w-3 h-3"}),Uploaded:t.jsx(A,{className:"w-3 h-3"}),Submitted:t.jsx(A,{className:"w-3 h-3"}),"Action Required":t.jsx(je,{className:"w-3 h-3"}),"Not Submitted":t.jsx(st,{className:"w-3 h-3"})};return t.jsxs("span",{className:`inline-flex items-center gap-1 px-2 py-0.5 rounded-full ${a[n]||a.Pending}`,style:{fontSize:"0.7rem"},children:[o[n]," ",n]})};return t.jsxs("div",{className:"space-y-4",children:[t.jsxs("div",{children:[t.jsx("h1",{className:"text-2xl font-bold",children:"Documents"}),t.jsx("p",{className:"text-muted-foreground text-sm mt-1",children:"Manage documents"})]}),W&&t.jsxs("div",{className:"bg-amber-50 border border-amber-200 rounded-lg p-3 flex items-start gap-2 animate-in fade-in slide-in-from-top-1",children:[t.jsx(je,{className:"w-4 h-4 text-amber-600 mt-0.5 shrink-0"}),t.jsxs("div",{children:[t.jsx("p",{className:"text-amber-800 font-semibold text-sm",children:"Action Required"}),t.jsx("p",{className:"text-amber-700 text-xs mt-1",children:"Please upload your signed Company Acceptance Form to verify and start your internship."})]})]}),(O||L)&&t.jsxs("div",{className:"bg-blue-50 border border-blue-200 rounded-lg p-3 flex items-start gap-2 animate-in fade-in slide-in-from-top-1",children:[t.jsx(T,{className:"w-4 h-4 text-blue-600 mt-0.5 shrink-0"}),t.jsxs("div",{children:[t.jsx("p",{className:"text-blue-800 font-semibold text-sm",children:L?"Internship Completed":"Final Report Due"}),t.jsx("p",{className:"text-blue-700 text-xs mt-1",children:u?"Your final internship report has been uploaded.":"Please upload your comprehensive final report below before the term ends."})]})]}),t.jsx("div",{className:"space-y-2",children:He.map(n=>t.jsxs("div",{className:`bg-card border rounded-lg p-3 space-y-2 transition-all ${n.status==="Action Required"?"border-red-200":"border-border"}`,children:[t.jsxs("div",{className:"flex items-start gap-2",children:[t.jsx("div",{className:`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${n.status==="Available"||n.status==="Uploaded"||n.status==="Submitted"?"bg-emerald-100":n.status==="Action Required"?"bg-red-100":"bg-secondary"}`,children:t.jsx(n.icon,{className:`w-4 h-4 ${n.status==="Available"||n.status==="Uploaded"||n.status==="Submitted"?"text-emerald-600":n.status==="Action Required"?"text-red-600":"text-muted-foreground"}`})}),t.jsxs("div",{className:"flex-1 min-w-0",children:[t.jsx("p",{className:"font-medium text-sm text-foreground",children:n.name}),qe(n.status)]})]}),t.jsx("p",{className:"text-xs text-muted-foreground line-clamp-2 ml-11",children:n.desc}),t.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-2 ml-11",children:[n.id==="acceptance-form"&&n.canDownload?t.jsxs(t.Fragment,{children:[t.jsxs("button",{onClick:Ee,disabled:R,className:"px-2.5 py-1.5 border border-primary text-primary hover:bg-primary/5 rounded text-xs font-medium flex items-center justify-center gap-1 transition-colors disabled:opacity-50",children:[t.jsx(Se,{className:"w-3 h-3"})," ",R?"Downloading...":"Download Form"]}),t.jsxs("button",{onClick:()=>m(!0),className:"px-2.5 py-1.5 border border-blue-300 text-blue-600 hover:bg-blue-50 rounded text-xs font-medium flex items-center justify-center gap-1 transition-colors",children:[t.jsx(_e,{className:"w-3 h-3"})," Invite Supervisor"]})]}):n.canDownload?t.jsxs("button",{onClick:()=>{n.id==="placement-letter"?Re():n.id==="insurance-letter"?ze():n.id==="logbook-form"?window.open("/logbook.pdf","_blank"):n.id==="logbook-export"?Oe():n.id==="final-report"&&K?window.open(K,"_blank"):n.id.startsWith("custom-")&&Me(n)},className:"px-2.5 py-1.5 border border-primary text-primary hover:bg-primary/5 rounded text-xs font-medium flex items-center justify-center gap-1 transition-colors",children:[t.jsx(Se,{className:"w-3 h-3"})," Download"]}):null,n.canUpload&&t.jsxs("button",{onClick:()=>{if(n.id==="acceptance-form"){if(!(e!=null&&e.id)){i.error("No application ID found to upload acceptance form.");return}P(!0)}else n.id==="final-report"&&y(!0)},className:"px-2.5 py-1.5 bg-primary text-primary-foreground hover:opacity-90 rounded text-xs font-medium flex items-center justify-center gap-1 transition-opacity",children:[t.jsx(De,{className:"w-3 h-3"})," ",n.id==="acceptance-form"?"Upload Signed Form":"Upload"]}),!n.canDownload&&!n.canUpload&&t.jsx("button",{disabled:!0,className:"px-2.5 py-1.5 bg-secondary text-muted-foreground rounded text-xs opacity-50 cursor-not-allowed flex items-center justify-center gap-1",children:"Not Available"})]})]},n.id))}),Te&&z&&t.jsx("div",{className:"bg-emerald-50 border border-emerald-200 rounded-lg p-4",children:t.jsxs("div",{className:"flex items-start gap-3",children:[t.jsx(A,{className:"w-5 h-5 text-emerald-600 mt-0.5 shrink-0"}),t.jsxs("div",{className:"flex-1 min-w-0",children:[t.jsx("h3",{className:"font-semibold text-emerald-900 text-sm",children:"Supervisor Invited"}),t.jsxs("p",{className:"text-emerald-700 text-xs mt-1",children:[t.jsx("span",{className:"font-medium",children:z})," (",H,")"]}),t.jsx("p",{className:"text-emerald-600 text-xs mt-2",children:"Access link sent. Link expires in 30 days."})]}),t.jsx("button",{onClick:()=>{H&&z&&ee(z,H,Q,Ue)},className:"ml-auto px-3 py-1.5 text-emerald-600 hover:bg-emerald-100 rounded text-xs font-medium whitespace-nowrap shrink-0 transition-colors",children:"Resend Invite"})]})}),e&&t.jsx(Qe,{isOpen:F,onClose:()=>P(!1),onSuccess:async n=>{Y(),n!=null&&n.name&&(n!=null&&n.email)&&await ee(n.name,n.email,n.phone,n.title)},applicationId:e.id,companyName:typeof((oe=e.company)==null?void 0:oe.name)=="string"?e.company.name:typeof e.companyName=="string"?e.companyName:"Company",studentName:((le=(re=e.student)==null?void 0:re.user)==null?void 0:le.name)??e.studentName??(s==null?void 0:s.name)??"Student",studentId:((de=e.student)==null?void 0:de.student_id)??e.studentId??(s==null?void 0:s.studentId),department:M(e,(s==null?void 0:s.department)??""),level:((ce=e.student)==null?void 0:ce.level)??e.level,companyAddress:typeof((me=e.company)==null?void 0:me.address)=="string"?e.company.address:void 0,proposedStartDate:e.proposed_start_date,proposedEndDate:e.proposed_end_date}),t.jsx(ct,{isOpen:$,onClose:()=>y(!1),onSuccess:Ae,title:"Upload Final Report",description:"Select your comprehensive internship report to upload (PDF, DOCX, or DOC formats allowed. Max 10MB)."}),t.jsx(mt,{isOpen:b,onClose:()=>m(!1),applicationId:e==null?void 0:e.id,initialName:z||"",initialEmail:H||"",initialPhone:Q||"",studentName:((ue=(pe=e==null?void 0:e.student)==null?void 0:pe.user)==null?void 0:ue.name)??(e==null?void 0:e.studentName)??(s==null?void 0:s.name)??"Student",companyName:typeof((ge=e==null?void 0:e.company)==null?void 0:ge.name)=="string"?e.company.name:typeof(e==null?void 0:e.companyName)=="string"?e.companyName:"Company"})]})}export{kt as DocumentsPage};
